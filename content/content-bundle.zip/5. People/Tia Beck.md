---
aliases: Tia, Turtle
tags: NPCs
Faction: Chapter
Role: Villager
Location: Chapter
Status: Alive
---
## Tia "Turtle" Beck
(Female, 24 yrs old, very nice but painfully shy, hides from conflict (turtles), very sharp with books). Her father, Simon, is influential among the “[[The Star League|Star League]]” believers and will barter well for good tech.