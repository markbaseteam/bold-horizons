---
aliases: The Ochre
tags: NPCs
Faction: Ferals
Role: Leader
Location: Northwest of Chapter 
Status: Alive
---
## Mighty Ochre

An unseen creature that could control moldie [[Ferals]].  It claimed [[Big Jim Haggart]] was a murderer and wanted him brought from [[Chapter]] to face punishment.