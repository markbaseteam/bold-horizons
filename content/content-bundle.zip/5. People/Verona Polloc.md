---
aliases: 
tags: NPCs
Faction: Chapter
Role: Villager
Location: Chapter
Status: Location
---
## Verona Polloc
(female, 17 yrs old, recently “of age”, very pretty, pursued, fascinated about what makes people different: race, Changes, etc. She has two brothers in the [[Chapter Militia|Militia]], one of whom ([[Bull Polloc|Bull]]) our heroes saved from the avalanche in Hazelwood.