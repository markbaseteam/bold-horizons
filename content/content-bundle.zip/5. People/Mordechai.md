---
tags: NPCs
Faction: Church of the Big Nothing
Role: Son
Location: Unknown
Status: Alive
---
## Mordechai
One of the sons of [[Father Obadiah Blank|Father Blank]].  He escaped from [[Hazelwood]].