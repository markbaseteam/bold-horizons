---
aliases: Big Jim
tags: NPCs
Faction: Chapter Militia
Role: Leader
Location: Chapter
Status: Alive
---
## Big Jim Haggart
The leader of the [[Chapter Militia]].