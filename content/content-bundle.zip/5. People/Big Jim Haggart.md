---
aliases: Big Jim, Big Jim's
tags: NPCs
Faction: Chapter Militia
Role: Leader
Location: Chapter
Status: Alive
---
## Big Jim Haggart
The leader of the [[Chapter Militia]].

![](https://i.imgur.com/oXo1aOa.png)