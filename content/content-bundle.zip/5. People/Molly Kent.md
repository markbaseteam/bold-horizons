---
aliases: Molly, Kent Family
tags: NPCs
Faction: Chapter
Role: Survivor
Location: Chapter
Status: Alive
---
## Molly Kent
The sole survivor of the Kent family. Her family fought back against [[Father Obadiah Blank|Father Obadiah Blank's]] people and were killed and she ran. She's being housed in [[Chapter]] for the winter.