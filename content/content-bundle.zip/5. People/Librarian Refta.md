---
aliases: Refta
tags: NPCs
Faction: Librarians
Role: Librarian
Location: Chapter
Status: Alive
---
## Librarian Refta
[[Masha Richards|Masha's]] current [[Librarians|Librarian]] teacher.  She is irritable.  