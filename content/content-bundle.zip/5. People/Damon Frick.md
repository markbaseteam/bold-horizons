---
aliases: 
tags: NPCs
Faction: Order of Silence
Role: Member
Location: Chapter
Status: Alive
---
## Damon Frick
(male, 19 yrs old, intelligent, firmly believes that [[Chapter]] should disband and people live in hiding as the aliens are sure to return any day now ([[Order of Silence]]), says he’ll make a survival homestead as soon as he has enough material.)