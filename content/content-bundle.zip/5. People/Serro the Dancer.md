---
tags: NPCs
Faction: Chapter Militia
Role: Member
Location: Chapter
Status: Alive
---
# Serro the Dancer
A member of the [[Chapter Militia]].  He is fast moving but ‘scrawny’.