---
tags: NPCs
Faction: Sacellum of Light
Role: Leader
Location: Chapter
Status: Alive
---
## Bishop Gabriel
Charismatic and Passionate. The leader of the [[Sacellum of Light]] in [[Chapter]].  He wants wants Chapter to become a theocracy under the rule of a revitalized Church, but he would never overthrow [[Elder Council|the Council]] by force.

![](https://i.imgur.com/7HJb9lj.png)