---
aliases: Xando Jones
tags: NPCs
Faction: Librarians
Role: Librarian
Location: Chapter
Status: Dead
---
## Librarian Jones
[[Masha Richards|Masha's]] former [[Librarians|Librarian]] teacher.