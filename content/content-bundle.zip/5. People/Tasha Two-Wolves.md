---
Aliases: Tasha Two-Wolves
Tags: Category/Individual Organization/Scouting-Guild Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Female 
Region: Wind River Valley 
Organization: Scouting Guild
Community: Chapter 
Status: Alive 
Player: NPC
---

# Tasha Two-Wolves

## Overview
**Region**: Wind River Valley
**Organization**: [[Scouting Guild]]
**Community**: Chapter
**Status**: Alive
**Player**: NPC

### Tasha Two-Wolves (Alive)

Often absent, effective, viciously practical, Tribal and spends winters on Tribal Land.

![](https://i.imgur.com/r0AjEmR.png)