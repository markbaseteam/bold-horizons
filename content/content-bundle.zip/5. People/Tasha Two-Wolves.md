---
aliases: 
tags: NPCs
Faction: Scouting Guild
Role: Tribal Scout
Location: Tribal Land
Status: Alive
---
## Tasha Two-Wolves
Often absent, effective, viciously practical, Tribal and spends winters on Tribal Land.