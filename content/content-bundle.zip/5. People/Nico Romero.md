---
Aliases: Nico Romero
Tags: Category/Individual Organization/The-Exotica Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: The Exotica
Community: Chapter 
Status: Alive
Player: NPC 
---

# Nico Romero

## Overview
**Region**: Wind River Valley
**Organization**: The Exotica
**Community**: Chapter
**Status**: Alive
**Player**: NPC

### Nico Romero (Alive)

Runs [[The Exotica]], the only high-end restaurant in the entirety of The After.
