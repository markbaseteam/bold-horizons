---
Aliases: Bill McDougal, Big Bill
Tags: Category/Individual Organization/Big-Bills Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: Big Bill's
Community: Chapter 
Status: Alive
Player: NPC
---

# Bill McDougal

## Overview
**Region**: Wind River Valley
**Organization**: Big Bill's
**Community**: Chapter
**Status**: Alive
**Player**: NPC

### Bill McDougal (Alive)
Owns [[Big Bill's Bar]] in Chapter.
