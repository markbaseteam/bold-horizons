---
aliases: 
tags: NPCs
Faction: Elder Council
Role: Healer
Location: Chapter
Status: Alive
---
## Doc Goode
Unaffiliated, runs [[Mercy Hospital]] with volunteers and on donations and funding from the [[Elder Council]]. Doc is getting on in years but studied all the medical books he could and learned from mentors for oral tradition medicine. Appreciates the power of herbs to heal.