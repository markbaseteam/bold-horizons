---
Aliases: Zachariah Cole
Tags: Category/Individual Organization/Scouting-Guild Region/Wind-River-Valley Community/Wanderer Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: Scouting Guild 
Community: Wanderer 
Status: Alive 
Player: NPC 
---

# Zachariah Cole

## Overview
**Region**: Wind River Valley
**Organization**: Scouting Guild
**Community**: Wanderer
**Status**: Alive
**Player**: NPC

### Zachariah Cole (Alive)

Zachariah Cole is known to every community in the [[Wind River Valley]]. He is a famous scout, explorer, and sharpshooter. He chooses to live a nomadic, solitary life, exploring The After. Cole visits [[Chapter]] once or twice a year to share knowledge with the [[Elder Council]].

![](https://i.imgur.com/FaUbKZ9.png)