---
tags: NPCs
Faction: Chapter
Role: Scout
Location: Wind River Valley
Status: Alive
---
## Zachariah Cole
Zachariah Cole is known to every community in the [[Wind River Valley]]. He is a famous scout, explorer, and sharpshooter. He chooses to live a nomadic, solitary life, exploring The After. Cole visits [[Chapter]] once or twice a year to share knowledge with the [[Elder Council]].