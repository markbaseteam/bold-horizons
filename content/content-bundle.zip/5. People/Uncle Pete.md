---
aliases: Uncle Pete's
tags: NPCs
Faction: Blackgold
Role: Leader
Location: Blackgold Station
Status: Alive
---
## Uncle Pete
The new leader at [[Blackgold Station]].  He is a dreadlocked man with a [[Remnant Eye]].

![](https://i.imgur.com/kJ61ayF.png)