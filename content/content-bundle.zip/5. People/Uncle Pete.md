---
tags: NPCs
Faction: Blackgold
Role: Leader
Location: Blackgold Station
Status: Alive
---
## Uncle Pete
The new leader at [[Blackgold Station]].  He is a dreadlocked man with a [[Remnant Eye]].