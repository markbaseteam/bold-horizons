---
aliases: 
tags: NPCs
Faction: The Star League 
Role: Member 
Location: Chapter 
Status: Dead 
---
## Brant

A member of [[The Star League]] that went to find [[Cletus|Cletus']] stake.  He was killed by moldie [[Ferals]].

![](https://i.imgur.com/ZoWSL72.jpg)