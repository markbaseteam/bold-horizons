---
Aliases: Shandra Pierce, Shandra
Tags: Category/Individual Organization/The-Blue-Sky-Tavern Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Female
Region: Wind River Valley 
Organization: The Blue Sky Tavern
Community: Chapter
Status: Alive
Player: NPC
---

# Shandra Pierce

## Overview
**Region**: [[Wind River Valley]]
**Organization**:  [[The Blue Sky Tavern]]
**Community**: [[Chapter]]
**Status**: Alive
**Player**: NPC

### Shandra Pierce (Alive)
Owns [[The Blue Sky Tavern]] in [[Chapter]].  
