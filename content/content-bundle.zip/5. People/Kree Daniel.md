---
aliases: 
tags: NPCs
Faction: Chapter
Role: Villager
Location: Chapter
Status: Alive
---
## Kree Daniel
(female, 18 yrs old, wants to be a [[Scouting Guild|Scout]], very curious, anxious about getting lost, long black hair – Arapaho Tribal blood). Being raised by her grandmother who gives a hard eye to any suitor.