---
Aliases: Kree Daniel, Kree, Kree's
Tags: Category/Individual Organization/The-Tribe Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Female 
Region: Wind River Valley 
Organization: The Tribe
Community: Chapter 
Status: Alive 
Player: NPC 
---

# Kree Daniel

## Overview
**Region**: [[Wind River Valley]]
**Organization**:  The Tribe
**Community**: [[Chapter]]
**Status**: Alive
**Player**: NPC

### Kree Daniel (Alive)

(female, 18 yrs old, wants to be a [[Scouting Guild|Scout]], very curious, anxious about getting lost, long black hair – Arapaho Tribal blood). 

Being raised by her grandmother who gives a hard eye to any suitor.