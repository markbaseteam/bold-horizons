---
Aliases: Doc Fisher
Tags: Category/Individual Organization/Doctor Region/Wind-River-Valley Community/Village of Daniel Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: Doctor
Community: Village of Daniel
Status: Alive 
Player: NPC
---

# Doc Fisher

## Overview
**Region**: Wind River Valley
**Organization**: Doctor
**Community**: [[Village of Daniel]]
**Status**: Alive
**Player**: NPC

### Doc Fisher (Alive)

A vet and doctor in [[Village of Daniel|Daniel]].  Is respected by the [[Librarians]] and able to borrow books.  Rumored to have run with [[Blackgold Trading Company]] when he was younger. 

![](https://i.imgur.com/yYHi56p.png)
