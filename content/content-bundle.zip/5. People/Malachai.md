---
tags: NPCs
Faction: Church of the Big Nothing
Role: Son
Location: Hazelwood
Status: Dead
---
## Malachai
One of the sons of [[Father Obadiah Blank|Father Blank]].  He was killed by [[Glurk]] in [[Hazelwood]].