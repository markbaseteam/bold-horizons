---
aliases: Silas Rook, Demerius Rook
tags: NPCs
Faction: The Star League
Role: 
Location: Chapter
Status: Alive
---
## Silas and Demerius Rook
Twins and fervent proponents of [[The Star League|the League]], one or the other can be found at [[Armstrong House]] any time.