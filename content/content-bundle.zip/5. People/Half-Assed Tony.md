---
aliases: 
tags: NPCs
Faction: Scouting Guild 
Role: Scout 
Location: Chapter 
Status: Alive 
---
## Half-Assed Tony
A member of the [[Scouting Guild]] who went with the Companions when they rescued [[Barnabus Quill|Quill]].  He stepped on a [[Phoenix State]] mine, but survived his injuries.