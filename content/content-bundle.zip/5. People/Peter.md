---
tags: NPCs
Faction: Elder Council
Role: Member
Location: Chapter
Status: Alive
---
## Peter
A member of the [[Elder Council]] in [[Chapter]]. Wasn't originally convinced the group was capable.