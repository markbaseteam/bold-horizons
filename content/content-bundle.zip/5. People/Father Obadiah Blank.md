---
aliases: Father Blank, Father Obadiah Blank's, Father Blank's
tags: NPCs
Faction: Church of the Big Nothing
Role: Leader
Location: Hazelwood
Status: Dead
---
## Father Obadiah Blank
He was a simple preacher and tinker until he entered a [[Breach Zone]].  Then became a zealot again the written word.  

He had two sons, [[Mordechai]] and [[Malachai]].

First attacked the [[Molly Kent|Kent Family]], then [[Hazelwood]] where he was killed.