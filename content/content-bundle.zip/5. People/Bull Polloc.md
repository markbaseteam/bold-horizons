---
tags: NPCs
Faction: Chapter Militia
Role: Member
Location: Chapter
Status: Alive
---
## Bull Polloc
A member of the [[Chapter Militia]].  He is a young man of 18 whose is stronger than about anyone else in [[Chapter]] (or so he'll claim). He is slow to anger and doesn't enjoy violence.