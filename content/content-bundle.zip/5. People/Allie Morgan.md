---
tags: NPCs
Faction: Librarians
Role: Chief Librarian
Location: Chapter
Status: Alive
---
## Allie Morgan
Chief [[Librarians|Librarian]] of [[Chapter]]. Keeper of the [[The Hearth|Hearth Ghost Shard]], has a [[Allie Morgan's Laboratory|personal laboratory]] (#8) with electricity and guards, experimenting on unlocking Old World Tech, Breach Energy, and more.