---
Aliases: Allie Morgan
Tags: Category/Individual Organization/Librarians Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Female 
Region: Wind River Valley
Organization: Librarians
Community: Chapter 
Status: Alive 
Player: NPC 
---

# Allie Morgan

## Overview
**Region**: [[Wind River Valley]]
**Organization**: [[Librarians]]
**Community**: [[Chapter]]
**Status**: Alive
**Player**: NPC

### Allie Morgan (Alive)

Chief [[Librarians|Librarian]] of [[Chapter]]. Keeper of the [[The Hearth|Hearth Ghost Shard]], has a [[Allie Morgan's Laboratory|personal laboratory]] (#8) with electricity and guards, experimenting on unlocking Old World Tech, Breach Energy, and more.

![](https://i.imgur.com/s3MF3OU.png)