---
aliases: Vicar Sheila
tags: NPCs
Faction: Sacellum of Light
Role: Leader
Location: Village of Daniel
Status: Alive
---
## Vicar Sheila Preston
The leader of the [[Village of Daniel]].  She is one of the [[Gifted]].