---
tags: NPCs
Faction: Highway Market
Role: Protector
Location: Highway Market
Status: Alive
---
## Raine
A female [[Helot]] that takes care of any problems at the [[Highway Market]] diner.