---
Aliases: Kate Runahan, Goodtime Kate, Kate
Tags: Category/Individual Organization/Party-Towne-Pub Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Female
Region: Wind River Valley 
Organization: Party Towne Pub
Community: Chapter 
Status: Alive 
Player: NPC
---

# Kate Runahan

## Overview
**Region**: Wind River Valley
**Organization**: Party Towne Pub
**Community**: Chapter
**Status**: Alive
**Player**: NPC

### Kate Runahan (Alive)

Runs the [[Party Towne Pub]].

![](https://i.imgur.com/DYHYgb6.png)
