---
aliases: 
tags: NPCs
Faction: Chapter
Role: Apprentice Blacksmith
Location: Chapter
Status: Alive
---
## Jack Marley
(male, 20 yrs old, apprentice blacksmith, strong, inventive but quick to anger, sweet face). 

Father is a farmer tending fields just outside the walls of [[Chapter]], mother is dead.