---
Aliases: Clarity
Tags: Category/Individual Organization/Highway-Market-Diner Region/Wind-River-Valley Community/Highway Market Individual/NPC Source/The-After
Gender: Female 
Region: Wind River Valley 
Organization: Highway Market Diner
Community: Highway Market
Status: Alive 
Player: NPC
---

# Clarity

## Overview
**Region**: Wind River Valley
**Organization**: Highway Market Diner
**Community**: [[Highway Market]]
**Status**: Alive
**Player**: NPC

### Clarity (Alive)

She cooks at the [[Highway Market]] diner, bakes the most delicious breads and pies, and is the de facto leader of the community. She's one of the most peaceful and civilized people in the [[Wind River Valley]] valley.

![](https://i.imgur.com/DRA51xK.png)