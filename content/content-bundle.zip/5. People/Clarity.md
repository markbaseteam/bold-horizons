---
tags: NPCs
Faction: Highway Market
Role: Leader
Location: Highway Market
Status: Alive
---
## Clarity
She cooks at the [[Highway Market]] diner, bakes the most delicious breads and pies, and is the de facto leader of the community. She's one of the most peaceful and civilized people in the [[Wind River Valley]] valley.