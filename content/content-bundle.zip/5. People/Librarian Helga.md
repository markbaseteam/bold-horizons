---
aliases: 
tags: NPCs
Faction: Librarians 
Role: Librarian 
Location: Chapter 
Status: Alive 
---
## Librarian Helga

An older [[Librarians|Librarian]] known by [[Masha Richards|Masha]].
