---
aliases: 
tags: NPCs
Faction: Garth
Role: Caravan member
Location:  Graves Outside Chapter
Status: Dead
---
## Kent Watchborn
A member of [[Garth Hernandez|Garth's]] former caravan.  He was heavy set with a beautiful singing voice. He was strong and good with the horses.

He was killed by [[Ferals]].