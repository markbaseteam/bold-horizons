---
aliases: 
tags: NPCs
Faction: Chapter
Role: Villager
Location: Chapter
Status: Alive
---
## Paul Veick
(male, 18 yrs old, handsome and knows it, not really found his calling yet, not a reader, but a real charmer). 

Parents are [[Librarians]] who don’t understand him. Can hang out where [[Masha Richards|Masha]] is if he wants to.