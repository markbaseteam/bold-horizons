---
Aliases: Shaun The Broker
Tags: Category/Individual Organization/The-Posthumans Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: The Posthumans
Community: Chapter 
Status: Alive 
Player: NPC
---

# Shaun The Broker

## Overview
**Region**: Wind River Valley
**Organization**: [[The Posthumans]]
**Community**: [[Chapter]]
**Status**: Alive
**Player**: NPC

### Shaun The Broker (Alive)

[[Changed]].  At [[Ace Brokerage]].

![](https://i.imgur.com/6v9mFyB.png)