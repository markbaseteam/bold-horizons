---
aliases: 
tags: NPCs
Faction: The Changed
Role: Broker
Location: Chapter
Status: Alive
---
## Shaun The Broker
[[Changed]].  At [[Ace Brokerage]].