---
aliases: McKeller family, Derek McKeller
tags: NPCs
Faction: McKellar
Role: Gang
Location: Sweetwater
Status: Alive
---
## McKellar Family
The McKellar family (led by Derek) rules Sweetwater and has a large gang of thugs called the [[Regulators]]. 