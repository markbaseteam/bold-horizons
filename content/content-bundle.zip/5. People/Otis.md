---
tags: NPCs
Faction: Blackgold
Role: Operative
Location: Chapter
Status: Alive
---
## Otis
The operative from [[Blackgold Trading Company]] in [[Chapter]].  Tried to get [[Garth Hernandez|Garth]] to form a trade deal between [[Blackgold Station]] and [[Phoenix State]].