---
aliases: Old Man Crow’s
tags: NPCs
Faction: Elder Council
Role: Wise Man
Location: Chapter
Status: Alive
---
# Old Man Crow
Old Man Crow is the oldest person in [[Chapter]]. While he holds a seat on the [[Elder Council]], he mostly stays in his cave in the cliffs overlooking the settlement, rarely becoming involved in day-to-day affairs.