---
Aliases: Cliff Westley, Westley
Tags: Category/Individual Organization/Scouting-Guild Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: Scouting Guild 
Community: Chapter 
Status: Alive 
Player: NPC 
---

# Cliff Westley

## Overview
**Region**: [[Wind River Valley]]
**Organization**: [[Scouting Guild]]
**Community**: [[Chapter]]
**Status**: Alive
**Player**: NPC

### Cliff Westley (Alive)

A veteran Scout of the Guild.
