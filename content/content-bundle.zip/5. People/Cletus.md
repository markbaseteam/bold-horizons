---
Aliases: Cletus', Dorothy
Tags: Category/Individual Organization/None Region/Wind-River-Valley Community/Wanderer Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: None
Community: Wanderer
Status: Alive 
Player: NPC
---

# Cletus

## Overview
**Region**: Wind River Valley
**Organization**: None
**Community**: Wanderer
**Status**: Alive
**Player**: NPC

### Cletus (Alive)
A scavenger and salvager.  Found a nice stash to the northwest of [[Chapter]].  

Has a mule named Dorothy and is in love with a woman named [[Miss Rachel|Rachel]] in [[Village of Daniel|Daniel]].

![](https://i.imgur.com/PykTMjT.jpg)