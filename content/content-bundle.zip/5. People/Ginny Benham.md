---
aliases: 
tags: NPCs
Faction: Sacellum of Light
Role: Member
Location:  Village of Daniel
Status: Alive
---
## Ginny Benham
A woman that took an interest in [[Garth Hernandez|Garth]] in the [[Village of Daniel]].