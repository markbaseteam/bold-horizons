---
aliases: Silas
tags: NPCs
Faction: Garth
Role: Caravan member
Location:  Graves Outside Chapter
Status: Dead
---
## Silas Boone
A member of [[Garth Hernandez|Garth's]] former caravan.  He was just a teenager and a good hunter/forager. He was a [[Changed]] and quiet.  

He was killed by [[Ferals]].