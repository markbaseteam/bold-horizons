---
Aliases: Quill
Tags: Category/Individual Organization/The-Star-League Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: The Star League
Community: Chapter 
Status: Alive
Player: NPC
---

# Barnabus Quill

## Overview
**Region**: [[Wind River Valley]]
**Organization**: [[The Star League]]
**Community**: [[Chapter]] 
**Status**: Alive
**Player**: NPC

### Barnabus Quill (Alive)

A member of [[The Star League]] who hired the companions to accompany [[Cletus]] to recover his stake northwest of Chapter.  
