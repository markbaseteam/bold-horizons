---
Aliases: Mama Carolla
Tags: Category/Individual Organization/Mama-Carollas-Boarding-House Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Female 
Region: Wind River Valley 
Organization: Mama Carolla's Boarding House
Community: Chapter 
Status: Alive 
Player: NPC 
---

# Mama Carolla

## Overview
**Region**: Wind River Valley
**Organization**: Mama Carolla's Boarding House
**Community**: Chapter
**Status**: Alive
**Player**: NPC

### Mama Carolla (Alive)

Runs [[Mama Carolla's Boarding House]].  