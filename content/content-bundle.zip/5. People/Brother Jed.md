---
aliases: Brother Jed “Hush”, Brother Jed "Hush"
tags: NPCs
Faction: Order of Silence
Role: Leader
Location: Chapter
Status: Alive
---
## Brother Jed

Zealot often seen around [[Chapter]] preaching. He took the Hush name like a title though some bristle at that.