---
aliases: Amanda
tags: NPCs
Faction: Garth
Role: Caravan member
Location:  Graves Outside Chapter
Status: Dead
---
## Amanda Cody
A member of [[Garth Hernandez|Garth's]] former caravan.  She was in her 40s and a sharp haggler.  But she couldn't keep her own caravan organized. She liked to play chess.

 She was killed by [[Ferals]].

