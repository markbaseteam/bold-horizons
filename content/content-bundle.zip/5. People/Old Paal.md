---
tags: NPCs
Faction: Chapter Militia
Role: Member
Location: Chapter
Status: Alive
---
# Old Paal
A member of the [[Chapter Militia]].  He doesn’t say much but will pay for beer sometimes.