---
tags: NPCs
Faction: Chapter
Role: Trader
Location: Chapter
Status: Alive
---
## Tilly Muscall
A trader that [[Garth Hernandez|Garth]] sometimes works with.  She runs a mule train.