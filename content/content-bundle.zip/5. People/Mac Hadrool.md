---
tags: NPCs
Faction: Chapter Militia
Role: Member
Location: Chapter
Status: Alive
---
## Mac Hadrool
A member of the [[Chapter Militia]].  He is an older militia member at 35 years old. Known mostly for his big red moustache, bald head, and penchant for singing dirty versions of local folk songs.