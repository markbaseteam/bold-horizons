---
Aliases: Darby
Tags: Category/Individual Organization/Sacellum-of-Light Region/Wind-River-Valley Community/Chapter Individual/NPC Source/The-After
Gender: Male
Region: Wind River Valley 
Organization: Sacellum of Light
Community: Chapter 
Status: Alive 
Player: NPC
---

# Darby Morgan

## Overview
**Region**: Wind River Valley
**Organization**: Sacellum of Light
**Community**: Chapter
**Status**: Alive
**Player**: NPC

### Darby Morgan (Alive)
[[Allie Morgan|Allie Morgan's]] cousin on [[Elder Council|the Council]].  Active in the [[Sacellum of Light]].
