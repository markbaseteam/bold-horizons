---
aliases: Feral, Blood Howlers
tags: Creature
---
# Ferals
Ferals are dangerous, humanoid creatures that scavenge the lands of The After, congregating in groups called gangs or tribes. Every gang of Ferals is [[Changed]], sometimes in profound ways. Each gang has a distinct ‘look’ that renders them obviously inhuman, and allows most viewers to easily distinguish one gang from another. In addition, the Change means some gangs of Ferals exhibit surprising and dangerous abilities.

**Moldie Feral**
![](https://i.imgur.com/ovHJlMx.png)

**Moldie Feral Beast**
![](https://i.imgur.com/MTkJfLg.png)