---
tags: Creature
---
# Butcher Bear
These immense creatures were constructed in [[Butcher]] bioforges, melding the aliens’ strange technology with vat-grown flesh. The Butcher bears’ genes were specially crafted, combining the dominant traits of several species of Earth bear with genetic material from an unknown alien predator species. The result was an unparalleled predator.

An average-size Butcher bear weighs 2,500 pounds, stands five feet tall at the shoulder, and when standing on its hind legs crests eleven feet. The largest adult males can grow up to 25% larger.