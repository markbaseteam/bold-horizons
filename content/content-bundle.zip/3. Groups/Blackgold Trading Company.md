---
tags: Groups
Faction: Blackgold
---
# Blackgold Trading Company
They used to be a vicious gang but there was a coup and they became a trading company, building [[Blackgold Station]]. 