---
aliases: Posthumans
tags: Groups
Faction: The Changed
Summary: 
---
# The Posthumans
“Augment yourselves, always.” 

- The [[Changed]]. 
- Average humans weren’t enough to defeat the Aliens. 
- Augment in any way possible to become more powerful. 
- Want [[Chapter]] to be a safe haven for the Changed. 
- Loose collection that tends to hang around the [[Ace Brokerage]] and Shaun “The Broker”.  

### Locations
- #21 [[Ace Brokerage]]  

### NPCs
- [[Shaun The Broker]]