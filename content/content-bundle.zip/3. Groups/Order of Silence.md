---
aliases:
tags: Groups
Faction: Order of Silence
Summary: 
---
# Order of Silence
“Mankind must vanish.”

- The aliens will return. 
- We must hide and breed. 
- Followers of this order live in small bunkers and caves near to [[Chapter]] proper, not wanting to become dependent on the town that must disappear. 
- Refer to members as Cousins. Obey the Silent Credo authored by the late Uncle Hush, founder. 
- Forbids over-the-air broadcasts. 
- Can’t build or farm where you can be seen from above. 
- They come to [[Chapter]] to beg everyone to disperse and live hidden on the land. 
- **Tension:** [[Chapter Militia|Militia]] is not a fan of their loud speeches and protests. 
- **Tension:** [[The Star League]] will only attract them faster.  

### Locations
- Bunkers and caves near [[Chapter]]

### NPCs
- [[Brother Jed|Brother Jed “Hush”]]