---
tags: Groups
Faction: Church of the Big Nothing
---
# Church of the Big Nothing
The "church" started by [[Father Obadiah Blank]] that all writing was evil. 

### NPCs
- [[Father Obadiah Blank]]
- [[Mordechai]]
- [[Malachai]]