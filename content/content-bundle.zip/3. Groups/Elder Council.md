---
aliases: The Council, the Council, Elder Council's
tags: Groups
Faction: Chapter
---
# Elder Council
The ruling council of [[Chapter]] (so far).

### Locations
- #1 [[Council House]]: When in session.
- #7 [[Mercy Hospital]]

### NPCs
- [[Old Man Crow]]
- [[Allie Morgan]]
- [[Big Jim Haggart]]
- [[Peter Black]]
- [[Doc Goode]]