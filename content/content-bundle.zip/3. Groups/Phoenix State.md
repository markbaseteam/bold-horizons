---
tags: Groups
Faction: Phoenix State
---
# Phoenix State
Few truths are known about the Phoenix State. They originate from somewhere to the distant east, beyond the [[Wind River Valley]], and screen off their territory with regular scouting flights and well-armed patrols. When they make an incursion into the Wind River Valley, it’s usually a large operation to delve the ruins of [[Old Buffalo]], the [[Fission Factory]], or [[Old Kaycee]] for parts, salvage, and whatever else of value they can haul off.