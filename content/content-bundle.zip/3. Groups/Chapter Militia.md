---
aliases: Militia
tags: Groups
Faction: Chapter
cssclass: clean-embeds
---
# Chapter Militia
“Defend the walls!”

- Under the [[Elder Council]]. 
- Volunteers. 
- Inside and outside of [[Chapter]]. 
- Drive out dangerous creatures and defend trade routes up to a day out from town. 
- Visit outlying farms. 
- Heavy patrols are usually 10 militia + 2 scouts. 
- Keep the peace inside the walls and enforce the laws. Groups of 3 inside the walls. Some see them as Bullies. 

[[Big Jim Haggart]] wants to use the Vault’s knowledge to build a strong military and take over neighbors to serve as buffers to keep [[Chapter]] safe. He also keeps lobbying the [[Elder Council]] to establish a cavalry (horses are precious).  

### Locations
- #1 [[Council House]] any time
- #5 Barracks.  

### NPCs
- [[Big Jim Haggart]]
- [[Bull Polloc]]
- [[Mac Hadrool]]
- [[Serro the Dancer]]
- [[Old Paal]]