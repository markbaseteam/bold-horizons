---
aliases: New Faith
tags: Groups
Faction: Sacellum of Light
---
# Sacellum of Light
“Smite the sinners!”

- The New Faith began with the remnants of Christianity. 
- Preach contrition in the face of God’s wrath. 
- [[Gifted|The Boon]] is God’s gift, [[Changed]] is demon-touched. 
- [[Butchers]] were demons and [[Ghosts]] were Angels. 
- Can be generous and help others. 
- Can be judgmental bullies. 
- Chastity, Charity, Temperance. 
- [[Bishop Gabriel]], the leader, lobbies that the church should lead [[Chapter]] but doesn’t condone violence to make it happen. 
- When things go poorly, more people come to services. 
- Public prayer, shaved heads, wear rags, flagellate. 
- A sizeable minority of Chapterites attend services.  

### Locations
- #14 [[Church of the New Faith]].  

### NPCs
- [[Bishop Gabriel]]
- [[Vicar Sheila Preston]]