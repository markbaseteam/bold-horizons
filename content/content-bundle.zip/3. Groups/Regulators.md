---
aliases: Derek McKeller
tags: Groups
Faction: McKellar
---
# Regulators
A large gang of thugs in [[Sweetwater]] that is loyal to the [[McKellar Family|McKeller family]].