---
aliases: Star League, the League
tags: Groups
Faction: The Star League
Summary: 
---
# The Star League
“We must escape this wretched rock.” 

- Must leave the Earth and travel the stars to avoid being victim to the next alien conquerors.
- Brilliant engineers and cackling madmen. 
- Salvaging the technology of space travel. 
- Declared [[Chapter]] the base of their operations. 
- Act as tech mechanics, buying and selling salvage. 
- Have Master Labs that are off-limits to non-members. 
- **Tension:** With the [[Sacellum of Light]] who thinks they are offending God.  

### Locations
- #19. [[Armstrong House]].  

### NPCs
- [[Silas and Demerius Rook]]
- [[Barnabus Quill]] 
- [[Evers]]  - killed by [[Ferals]] 
- [[Brant]]  - killed by [[Ferals]] 