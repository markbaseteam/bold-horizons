---
aliases: The Guild
tags: Groups
Faction: Chapter
---
# Scouting Guild
“Into the Breach, my friends!”

- Friends and followers of [[Zachariah Cole]], legendary trader and scout. 
- Strong-knit cadre. 
- Believe [[Chapter]] needs eyes and ears on the world. 
- Quest into the changed world and [[Breach Zone|Breach Zones]] to find advantages. 
- For a price will guide and protect expeditions. 
- Pay for maps of [[Breach Zone|Breach Zones]] or specimens of unknown creatures. 
- Walk and monitor up to a day distant from [[Chapter]] regularly.  

### Locations
- #18. [[Scouting Guildhouse]].

### NPCs
- [[Tasha Two-Wolves]] 
- [[Zachariah Cole]]
