---
aliases: Librarian, The Library, the Library
tags: Groups
Faction: Chapter
---
# Librarians
“We will teach the world.” 

- Knowledge is sacrosanct. 
- Copy the books, maintain the vaults, guard duty, memorizing as much information as possible. 
- Librarians can be underground for entire seasons. 
- They do rounds as teachers for the kids in [[Chapter]]. 
- Journeymen travel to find more pre-[[Butchers|Harvest]] print material usually in salvage runs and exploring underground places. 
- Employ others as paper makers and scribes. 
- Pay well for new material. 
- Respected by the people of [[Chapter]]. 
- **Tension:** Want to spread knowledge freely, the [[Elder Council]] wants to leverage it for the benefit of chapter.  

### Location
- #15 [[Mine Entrance]]
- #8 [[Allie Morgan's Laboratory]]  

### NPCs
- [[Allie Morgan]]
- [[Librarian Jones]]
- [[Librarian Refta]]
- [[Librarian Helga]]
