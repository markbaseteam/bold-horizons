---
aliases: the Watchmen
tags: Groups
Faction: Sacellum of Light
---
# The Watchmen
Armed members  who patrol and scout the [[Village of Daniel]] against [[Ferals]].