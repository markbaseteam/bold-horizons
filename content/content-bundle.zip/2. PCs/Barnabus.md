---
Aliases: Barnabus' 
tags: PCs
Player: Mark Gilicinski 
Race: Human
Concept: "Amish Hero"
---
