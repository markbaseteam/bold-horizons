---
Aliases: Glurk's
tags: PCs
Player: Jim Dugger
Race: Helot
Concept: Soldier
---
# Glurk
**Helot Soldier**

Like all [[Helot|Helots]], Glurk has short legs, wide shoulders, and unusually long arms. His powerful musculature can bear heavy loads and his physiology is resilient to toxins and extremes of temperature.

Glurk firmly believes that [[Kraim]] has guided him to [[Chapter]] to care for the people there. He’s acted as a caretaker by joining the Chapter Militia, doing his best to separate troublemakers and keep internal conflict to a minimum.

Glurk can’t wait for [[Kraim]] to return and take the [[Helot|Helots]] back to the stars, so he likes to pray as loudly as possible, to ensure Kraim can hear. As a reward for this prayer, a priest of Kraim visited Glurk, and gave him a holy task. She told him that there is a tiny settlement of Helots - just a few families - not far from the ruins of [[Old Lander]]. She asked Glurk to see that they are kept out of harm’s way!

From [[Cloudhaven]].

![](https://i.imgur.com/mDvrLoy.png)