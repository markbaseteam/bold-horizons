---
Aliases: Karx's
tags: PCs
Player: Mark Gilicinski
Race: Changed
Concept: Explorer
---
# Karx
**Changed Explorer**

Being born [[Changed]] can be a death sentence in many communities in The After. But the [[Elder Council]] of [[Chapter]] doesn’t believe in discriminating against mutants simply because they bear the scars of [[Butchers|the Harvest]] and [[the War]] in their DNA. Because of this, Karx has been able to carve out a career on the outskirts of Chapter, by turns serving as trail scout, scavenger, and repairman. The spikes protruding from his subdermal plating have a tendency to bleed around the bases, so he often wraps his limbs in rags.

Karx hopes to someday earn a place in the [[Scouting Guild]] of [[Chapter]]. Perhaps if he were able to capture the maps and navigational data that these invaders are using, he would be rewarded by the Scouts! Being able to show a charted route to the [[Phoenix State]] homeland would surely be enough to get Karx entry into the Guild.

![](https://i.imgur.com/b01q5qN.png)