---
Aliases: Garth, Garth's
tags: PCs
Player: Mark Daymude
Race: Human
Concept: "Former Free Trader"
---
# Garth Hernandez
**Human Former Free Trader**

Garth had been living a charmed life as a merchant, traveling from one end of [[Wind River Valley]] to the other. It all fell to pieces during his most recent caravan, when a horde of [[Ferals]] swarmed out of a nearby [[Breach Zone]]. Fortunately, the always-lucky Garth had been taking a shift as a forward scout when the ambush fell, and managed to escape to [[Chapter]] to raise the alarm with the [[Chapter Militia]]. However, his caravan, his companions, and all of his trading capital were lost and he’s starting his career back at square one.

The nefarious [[Blackgold Trading Company]] has privately contacted Garth. [[Otis|Their operative]] hinted that he had pulled strings to get Garth included in the mission. If he can set up trading between [[Blackgold Station]] and the [[Phoenix State]], there’s an enormous amount of wealth to be made. The Blackgold leadership isn’t concerned about the success of the Elder Council’s mission or the potential danger to Chapter - profit is what’s important to them. There’s a big percentage for Garth, if he can make this happen. You’ll need to decide: is it worth it?

### Friends and Contacts
Friends who worked his caravan and died in the [[Ferals]] attack: 
- [[Kent Watchborn]] (heavy set, beautiful singing voice, strong and good with the horses)
- [[Amanda Cody]] (in her 40s, sharp haggler but couldn't keep her own caravan organized, liked to play chess)
- [[Silas Boone]] (teenager, good hunter/forager, quiet, Changed).  

### Opinions on People and Groups

- [[Elder Council]] -- 3 - *"The Council isn't perfect, but they do a good job of running Chapter.  Certainly it is better the devotees at [[Village of Daniel|Daniel]] and that asshole [[McKellar Family|McKellar]].  The [[Highway Market]] might be better, but it is also a quarter the size.  Don't even get me started on [[Blackgold Station|Blackgold]]."*
- [[Chapter Militia]] -- 4 - *"I did my year in the Militia when I was younger.  Hard work and dangerous.  Plus, they saved my butt when the caravan was attacked."*
- [[Big Jim Haggart]] -- 3 - *"When you have a hammer everything is a nail.  People that complain should think about who might be the replacement."*
- [[Sacellum of Light]] -- 2 - *"I'm not a big fan of [[Bishop Gabriel]] but [[Vicar Sheila Preston|Vicar Sheila]] is nice enough.  Still never want to spend longer in Daniel than needed."*
- [[The Posthumans]] -- -1 - *"I ain't got nothing against the [[Changed]].  [[Silas Boone|Silas]] was Changed and he was a good man.  But these guys want everyone to be Changed.  I like myself the way I am, thank you very much."*
- [[Skav Burrow]] -- -1 - *"It is weird enough living in the same cabin with [[Meeka]].  A whole hill of them and their crazy ways?  I'd rather be stuck in Church instead."*
- [[Order of Silence]] -- -5 - *"One of these nutjobs tried to shoot [[Amanda Cody|Amanda]] once.  Asked us to track down a particular scrap item.  Then freaked out about us 'Calling down the [[Butchers]]' when we got close to his compound.  That guy better believe if I ever can call down the Butchers, he'll be the first target."*
- [[Scouting Guild]] -- 4 - *"It's a dangerous but very necessary job they do.  Hopefully [[Kree Daniel|Kree]] can overcome her fears and be able to join them.  [[Karx]] too I guess."*
- [[The Star League]] - 2 - *"They want to build a spaceship?  Man, they can't even get the rusted out RV in the [[Chapter Marketplace|Marketplace]] to run.  Still, they pay well when you find something interesting."*
- [[Librarians]] -- 2 - *"Wasn't a big fan at the time, but hard not to appreciate the school they got set up.  Learned pretty much everything I needed to know about being a trader there.  Even the stuff they didn't teach in books."*
- [[Chapter Marketplace]] -- 7 - *"[[Kate Runahan|Goodtime Kate]], [[Shandra Pierce|Shandra]], and [[Bill McDougal|Big Bill]] all run nice places.  But if you were want to meet and talk to people, the Marketplace is where you want to be.  Its been nice seeing old friends from the trail show up on occasion since I'm not out there myself."*

![](https://i.imgur.com/h1E2iZK.jpg)