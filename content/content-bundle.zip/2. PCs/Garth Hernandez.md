---
Aliases: Garth, Garth's
tags: PCs
Player: Mark Daymude
Race: Human
Concept: "Former Free Trader"
---
# Garth Hernandez
**Human Former Free Trader**

Garth had been living a charmed life as a merchant, traveling from one end of [[Wind River Valley]] to the other. It all fell to pieces during his most recent caravan, when a horde of [[Ferals]] swarmed out of a nearby [[Breach Zone]]. Fortunately, the always-lucky Garth had been taking a shift as a forward scout when the ambush fell, and managed to escape to [[Chapter]] to raise the alarm with the [[Chapter Militia]]. However, his caravan, his companions, and all of his trading capital were lost and he’s starting his career back at square one.

The nefarious [[Blackgold Trading Company]] has privately contacted Garth. [[Otis|Their operative]] hinted that he had pulled strings to get Garth included in the mission. If he can set up trading between [[Blackgold Station]] and the [[Phoenix State]], there’s an enormous amount of wealth to be made. The Blackgold leadership isn’t concerned about the success of the Elder Council’s mission or the potential danger to Chapter - profit is what’s important to them. There’s a big percentage for Garth, if he can make this happen. You’ll need to decide: is it worth it?

### Friends and Contacts
Friends who worked his caravan and died in the [[Ferals]] attack: 
- [[Kent Watchborn]] (heavy set, beautiful singing voice, strong and good with the horses)
- [[Amanda Cody]] (in her 40s, sharp haggler but couldn't keep her own caravan organized, liked to play chess)
- [[Silas Boone]] (teenager, good hunter/forager, quiet, Changed).  

![](https://i.imgur.com/h1E2iZK.jpg)