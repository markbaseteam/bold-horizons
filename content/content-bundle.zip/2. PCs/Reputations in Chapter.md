---
tags: Repuation
---

Through Episodes 1, 2, 3 - All rose to Reputation 3 out of 10 within [[Chapter]] and environs. Most people know you in town and have heard of at least one of your exploits.  
  
Episode 4 - Since [[Big Jim Haggart]] took all the credit for once again wiping out the Moldie [[Ferals]], your Reputation in Chapter remains at 3.

## PCs Opinions of People and Groups

| Factions           | Garth | Glurk | Meeka | Masha | Karx |
| ------------------- | ----- | ----- | ----- | ----- | ---- |
| [[Elder Council]]       | 3   |       |       |       |      |
| [[Chapter Militia]]     | 4   |       |       |       |      |
| [[Big Jim Haggart]]     | 3   | -5    |       |       |      |
| [[Sacellum of Light]]   | 2   |       |       |       | -5   |
| [[The Posthumans]]      | -1  |       |       |       |      |
| [[Skav Burrow]]         | -1  |       |       |       |      |
| [[Order of Silence]]    | -5  |       |       |       |      |
| [[Scouting Guild]]      | 4   |       |       |       |      |
| [[The Star League]]     | 2   |       |       |       |      |
| [[Librarians]]          | 2   |       |       |       |      |
| [[Chapter Marketplace]] | 7   |       |       |       | 3    |
 
## People and Groups Opinions of the PCs

| Factions                    | Garth | Glurk | Meeka | Masha | Karx |
| --------------------------- | ----- | ----- | ----- | ----- | ---- |
| General                         | 3     | 3     | 3     | 3     | 3    |
| [[Elder Council]] thinks...     | 2     | 2     | 2     | 2     | 2    |
| [[Chapter Militia]] thinks..    | 1     | 3     | 1     | 1     | 1    |
| [[Big Jim Haggart]]             | 1     | -1    | -1    | 3     | 1    |
| [[Sacellum of Light]] thinks... | 0     | -2    | 0     | 0     | -2   |
| [[The Posthumans]] think...     | 0     | 0     | 0     | 0     | 2    |
| [[Skav Burrow]] thinks...       | 0     | 0     | 3     | 0     | 0    |
| [[Order of Silence]] thinks...  | 0     | 0     | 0     | 0     | 0    |
| [[Scouting Guild]] thinks...    | 0     | 0     | 0     | 0     | 4    |
| [[The Star League]] thinks...   | 0     | 0     | 0     | 0     | 0    |
| [[Librarians]] think...         | 1     | 2     | 1     | 3     | 1    |
