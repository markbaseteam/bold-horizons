---
Aliases: Meeka's
tags: PCs
Player: Jeffrey Rees
Race: Skav
Concept: Gatherer 
---
# Meeka
**Skav Gatherer**
  
Meeka is into everything – everything! There are few places Meeka cannot get to, be it climbing, sneaking, or just because Meeka is small. Meeka earns items to trade by entertaining crowds with acrobatics and legerdemain.

![](https://i.imgur.com/C1TMy6D.png)
![](https://i.imgur.com/0DFyPie.jpg)