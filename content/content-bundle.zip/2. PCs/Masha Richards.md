---
Aliases: Masha, Masha's
tags: PCs
Player: Jo Gilicinski
Race: Human
Concept: Librarian's Apprentice
---
# Masha Richards
**Human Librarian's Apprentice**

Masha has lived within the walls of [[Chapter]] all her life, toiling at academic pursuits. Her intentions to become a [[Librarians|Librarian]] came to an abrupt halt, when her Librarian teacher, [[Librarian Jones|Xando Jones]], went missing on an expedition to examine a strange phenomenon in the ruins of [[Old Lander]]. When word came that [[Elder Council|the Council]] planned a follow-up mission, she clamored to be included. If her teacher can’t be found, perhaps she can recover his notes - or at least show enough initiative and worth to be inducted into the Librarians despite an unfinished apprenticeship!

![](https://i.imgur.com/KkY7a0J.png)