---
Aliases: Lefty's
tags: PCs
Player: Jeffrey Rees 
Race: Human
Concept: "Breech Runner" 
--- 
From Jeremiah Creek, as is Barnabus. A bit of Amish community.

In Jeremiah, a micro-breach opened up and one of the leader's kids fell in. Lefty (not known as that at the time) reached in with his right arm and pulled the kid out. The kid and his arm was saturated in breach energy.

Over time, both his arm and the kid faded. Lefty could still feel his arm, and he discovered he could "reach" into this other energy world with his "missing" right arm. To him, it still feels there, but of course it does not interact with the "real world"

But the settlement was not understanding about this situation. Even though he tried to save the kid, blame started to shift to him when people saw he could open one of these micro-breaches (ie, one day he cast a Power). Seeing the writing on the wall, he fled (thus the Wanted-Minor hindrance). Lefty still hears the child every now and then (Nathan shall be the name). That has slowly guided him on his travels as he looks for places where the energy is both strong and the veil thin. He can be heard talking to him on occasion (Quirk). He has heard that Chapter is more tolerant of people that are different, so his winding path is leading that way.