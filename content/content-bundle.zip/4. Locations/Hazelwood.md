---
tags: Location
---
# Hazelwood
### Location

### Description
A small mining settlement near [[Chapter]].

### Places

### NPCs
- [[Father Obadiah Blank]]