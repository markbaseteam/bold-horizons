---
tags: Location
---
# Smokey's
The big bar at [[Blackgold Station]].  There is an arena for bare-knuckle brawls in the back room.