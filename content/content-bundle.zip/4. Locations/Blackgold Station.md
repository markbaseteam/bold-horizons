---
aliases: Blackgold, The Station
tags: Location
---
# Blackgold Station
### Location
Located south of [[Village of Daniel|Daniel]] and north of [[Highway Market]].

### Description
They used to be a vicious gang but there was a coup and they became a trading company, building [[Blackgold Station]]. Somehow they have a supply of fuel so if you can find a generator, vehicle, etc. you can get the fuel here. The Station is nearly lawless or certainly rough and tumble.

**Population:** 100 gangers, 150 overall

### Places
- [[Smokey's]]

### NPCs
- [[Uncle Pete]]