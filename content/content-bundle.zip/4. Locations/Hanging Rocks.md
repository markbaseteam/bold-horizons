---
tags: Location
---
# Hanging Rocks
### Location
Located to the southeast of [[Chapter]].

### Description
- marauders sometimes attack [[Highway Market]]

### Places

### NPCs