---
Aliases: Verdant
Tags: Category/Geographical Region/Wind-River-Valley Terrain/Breach Zone Jungle Source/The-After
Region: Wind River Valley 
Terrain: Breach Zone Jungle

---
# The Verdant

## Overview
**Region**: Wind River Valley
**Terrain**:  Breach Zone Jungle

“On the one hand, it’s full of mud, filth, poisonous plants, disease-carrying bugs, and critters that’d happily tear off your limbs. On the other hand, there’s harvesting to be done for those with the knowledge, and it’s warm all year round. There’s something to be said for getting out of the damn snow. Anyway, just don’t let [[Big Jim Haggart|Big Jim]] catch you bringing back [[beamfruit]] into [[Chapter]].”

- [[Zachariah Cole]]

### The Verdant (Breach Zone Jungle)

