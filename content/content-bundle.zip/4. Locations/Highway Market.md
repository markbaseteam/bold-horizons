---
tags: Location
---
# Highway Market
### Location
Located south of [[Blackgold Station]].

### Description
Is a smaller settlement with about 100 people there and in farmsteads around the area. They raise livestock and do some farming. The settlement was built around a pre-invasion diner with brick and rebar town walls.

### Places
- Highway Market Diner 

### NPCs
- [[Clarity]]
- [[Raine]] 