---
tags: Location
---
# Old Lander
Ruins that the [[Phoenix State]] established a base at.  Is inhabited by a [[Butcher Bear]].