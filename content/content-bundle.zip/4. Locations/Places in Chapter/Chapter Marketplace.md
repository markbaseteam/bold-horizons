---
aliases: Marketplace
tags: Location, ChapterLocation 
---
## Chapter Marketplace

While Chapter doesn’t have too much in the way of dedicated storefronts, the Council has reserved this wide, flat space for folk to gather on Sundays to haggle, swap stories, and meet travelers.