---
aliases: 
tags: Location, ChapterLocation 
---
## Allie Morgan's Laboratory

This building is surprisingly sturdy, with very few windows, none of which are big enough to permit passage to an adult human. The laboratory is secured with steel security doors that have Old World locks installed. As well, at least four guards are on duty around the clock. Electric power is present at all times, as the facility is lit night and day. [[Allie Morgan]] uses generators to provide power for her experiments, as she tries to pry into the secrets of the [[Butchers]] and [[Ghosts]] in hopes of reawakening Old World technology. In particular, this building is home to the Ghost Shard known as “[[The Hearth]]”.