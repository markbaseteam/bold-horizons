---
aliases: Mill
tags: Location, ChapterLocation 
---
## Chapter Mill

[[Elder Council|The Council]] controls this impressive structure. Everyone is allowed to grind their grain here while the stream is running enough to power the wheel, so long as they provide a tithe.