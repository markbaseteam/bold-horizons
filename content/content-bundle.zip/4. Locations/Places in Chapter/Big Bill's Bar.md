---
aliases: Big Bill's
tags: Location, ChapterLocation 
---
# Big Bill's Bar

A rowdy bar in [[Chapter]] owned by [[Bill McDougal]].  A place where deals are done with drinking songs and brawls in the background.
