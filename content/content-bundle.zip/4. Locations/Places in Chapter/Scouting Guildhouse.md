---
aliases: 
tags: Location,ChapterLocation 
---
## Scouting Guildhouse

This unassuming cabin is identical to the family dwellings that surround it. Maintained by [[Breach Zone]] explorer [[Tasha Two-Wolves]], this is where members of the Scouts’ Guild can take off their boots and rest for a few days between missions.

### NPCs

- [[Zachariah Cole]].