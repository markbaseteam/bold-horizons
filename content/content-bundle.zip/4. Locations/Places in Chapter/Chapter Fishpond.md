---
aliases: Fishpond
tags: Location, ChapterLocation 
---
## Chapter Fishpond

The stream that flows through [[Chapter]] was diverted into a large pond and stocked with fish. Now it serves as a vital protein supply for the town.

### NPCs

- [[Gill]]