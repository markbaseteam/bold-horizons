---
aliases: Blue Sky
tags: Location, ChapterLocation
---
# The Blue Sky Tavern

A homey bar in [[Chapter]].  It is owned by [[Shandra Pierce]] who doesn't tolerate troublemakers.

[[Garth Hernandez|Garth]] buys sweet bread there for [[Kree Daniel|Kree's]] grandmother.