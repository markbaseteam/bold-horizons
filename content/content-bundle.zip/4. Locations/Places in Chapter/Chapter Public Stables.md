---
aliases: Public Stables
tags: Location,ChapterLocation 
---
## Chapter Public Stables

Visitors who bring their own feed, haul their own water, and keep their own guard can use this facility for free.