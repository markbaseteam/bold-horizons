---
aliases: 
tags: Location, ChapterLocation 
---
## Party Towne Pub

“[[Kate Runahan|Goodtime Kate]]” Runahan recently took over operation of this hole-in-the-wall drinking establishment. In addition to installing a food menu, she’s redecorated the place with carpets and cushions rather than wooden tables and chairs. Kate keeps the place open until dawn nearly every night.