---
aliases: Barracks
tags: Location, ChapterLocation 
---
## Chapter Barracks

The [[Chapter Militia|Militia]] is about fifty strong at any given time, including about a dozen full-time veterans led by [[Big Jim Haggart]].  While serving in the Militia, it’s expected that recruits will live in the barracks, to be armed and ready in the event they are called upon.