---
aliases: 
tags: Location, ChapterLocation 
---
## Companions Cabin

The cabin given to the companions for the winter by the [[Elder Council]] for [[Session 02 - The Right Hand of Nothing|their help]] in stopping [[Father Obadiah Blank]].

The rectangular room at the top of the map is a loft/attic/storage space - that is where the ladder is leading up to. While [[Meeka]] technically has a room with [[Masha Richards|Masha]] (females), she hangs out up in the attic quite a bit.

The two bedrooms are add-ons to the original cabin (thus the different wall type). [[Karx]] and [[Garth Hernandez|Garth]] are in the left room, Meeka and Masha in the other, and [[Glurk]] in the more broken down bed (he is too big) behind the privacy screen. The small building on the right is a shed. And, of course, the outhouse is on the left (facing the entrance).

![](https://i.imgur.com/iLtFoT5.jpg)