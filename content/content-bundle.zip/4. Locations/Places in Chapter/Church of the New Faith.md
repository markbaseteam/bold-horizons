---
aliases: 
tags: Location, ChapterLocation 
---
## Church of the New Faith

This humble church of wood was lovingly built by members of the [[Sacellum of Light]], who attend each Sunday to show their contrition before their deity.  [[Bishop Gabriel]] presides most Sundays, though he regularly lends the pulpit to visiting preachers, especially [[Vicar Sheila Preston|Vicar Sheila]] from the town of [[Village of Daniel|Daniel]], who visits once a season if she can.