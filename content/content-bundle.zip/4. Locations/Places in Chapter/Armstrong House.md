---
aliases: 
tags: Location, ChapterLocation 
---
## Armstrong House

At the outskirts of town, the scientists of [[the Star League]] maintain this laboratory complex and observatory, where they scan the skies for signs of the [[Ghosts]] and [[Butchers]].