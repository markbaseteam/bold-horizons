---
aliases: 
tags: Location, ChapterLocation 
---
## Council House

This two-story structure is well-fortified, with reinforced doors and windows and an outer wall faced with thick stone bricks. It was the original dwelling for the townsfolk when they first emerged from the mines.  

What was once a central sleeping chamber for the first wave of surface dwellers has been repurposed as a meeting place for the [[Elder Council|Elder Council's]] official business.