---
aliases: Mercy
tags: Location, ChapterLocation 
---
## Mercy Hospital

This brick building is sparkling clean and well-staffed. It has medical equipment and a finely educated medical staff.  It is subsidized by the [[Elder Council]], though barter goods are expected for the cost of supplies.