---
aliases: 
tags: Location, ChapterLocation 
---
## Lacey's Playhouse

With this brand new theater seating up to 100, [[Lacey Jones]] has reintroduced the joy of public performances to the folk of [[Chapter]].