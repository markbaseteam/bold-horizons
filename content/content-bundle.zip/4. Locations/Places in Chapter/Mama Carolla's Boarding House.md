---
aliases: 
tags: Location,ChapterLocation 
---
## Mama Carolla's Boarding House

Recently expanded, Mama’s offers every sort of lodging, from well-appointed private suites to shared lodging in the barracks-style bunkhouse.  [[Mama Carolla|Mama]] provides one rudimentary meal a day, locks the front gate at sunset, and enforces ‘quiet time’ after dinner is served.

### NPCs

- [[Hymie]] and [[Lacura]]