---
aliases: Schoolhouse
tags: Location, ChapterLocation 
---
## Chapter Schoolhouse

With Chapter’s thriving expansion, there are plenty of children who need to be brought up in a culture of learning.  It is run by the [[Librarians]].