---
aliases: 
tags: Location, ChapterLocation 
---
## Blackgold Trading Outpost

[[Uncle Pete|Uncle Pete's]] finest maintain a waystation for [[Blackgold Trading Company]] members here.

### NPCs

- [[Otis]]