---
aliases: 
tags: Location, ChapterLocation 
---
## Mine Entrance

This unassuming entrance reveals the Old World mines where the survivors of [[Butchers|the Harvest]] took shelter.