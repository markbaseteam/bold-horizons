---
aliases: 
tags: Location, ChapterLocation 
---
## The Exotica

This restaurant’s dining room is undoubtedly one of the finest places in town to sit and take in a sunset - if one can afford the asking price. The proprietor, [[Nico Romero]], runs what is undoubtedly the only high-end restaurant in the entirety of The After.