---
Aliases: Wind River, the Valley
tags: Location
---
# Wind River Valley
![](https://i.imgur.com/Ft1d75S.jpg)