---
aliases: The Claim
tags: Location
---
# Sweetwater
### Location
Located to the south of [[Highway Market]].

### Description
Fertile lands they call "The Claim". Over 400 people across their lands. The [[McKellar Family|McKellar family]] (led by Derek) rules Sweetwater. Most others are tenant farms in a sort of feudal system under the McKellars.  

### Places

### NPCs
- [[McKellar Family]]