---
Aliases: Chapter's
Tags: Category/Community Community/Chapter Region/Wind-River-Valley Community_Size/Town Source/The-After
Community_Size: Town
Population: 1000
Region: Wind River Valley
Founded: 2090
---

# Chapter

## Overview
**Founded**: 2090
**Community Size**: Town
**Region**: Wind River Valley
**Population**: 1000

### Chapter  (Town)

Chapter is a shining beacon, a counterpoint to the madness that gripped the world. In the mountains of the northwest United States, a group of determined survivors dug deep and hid well. They weathered the [[Butchers]], and the [[Ghosts]], and [[the War]]. They lived in the dark and stayed quiet, a full generation surviving as best they could underground.

In the bunkers under the cliffs, they had stashed thousands of books -- a veritable treasure trove of the world before. The founders of Chapter knew that in The After, the words in those books would be the only thing saving their descendants from a life of primitive savagery. The libraries were guarded and protected better than any man or woman of the community. The books came first - the words of the old world were paramount.

Now, after [[The Breaking|the Breaking]], the [[Elder Council]] of Chapter has deemed it safe enough to begin rebuilding. They’ve supervised the beginnings of a town in their cliffside valley. Their scouts have spread throughout the [[Wind River Valley]], bearing messages of prosperity through trade and knowledge. The Elder Council would dole out the knowledge of the Great Archive in return for peace and kinship.

## Places

- #1 [[Council House]]
- #2 [[Chapter Mill|Mill]]
- #3 [[Chapter Marketplace|Marketplace]]
- #4 [[Chapter Schoolhouse|Schoolhouse]]
- #5 [[Chapter Barracks|Barracks]]
- #6 [[Chapter Public Stables|Public Stables]]
- #7 [[Mercy Hospital]]
- #8 [[Allie Morgan's Laboratory]] 
- #9 [[The Blue Sky Tavern]]
- #10 [[Big Bill's Bar]] 
- #11 [[Party Towne Pub]]
- #12 [[Mama Carolla's Boarding House]]
- #13 [[The Exotica]]
- #14 [[Church of the New Faith]]
- #15 [[Mine Entrance]]
- #16 [[Lacey's Playhouse]]
- #17 [[Blackgold Trading Outpost]]
- #18 [[Scouting Guildhouse]]
- #19 [[Armstrong House]] 
- #20 [[Chapter Fishpond|Fishpond]]
- #21 [[Ace Brokerage]]
- [[Companions Cabin]]
- [[Skav Burrow]]

## Factions

![](https://i.imgur.com/MFhl53B.png)

![](https://i.imgur.com/ClgJML5.png)