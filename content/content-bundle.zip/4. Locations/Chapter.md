---
aliases: Chapter's
tags: Location
---
# Chapter
Nearly sixty years after the Butchers’ arrival on Earth, there is no longer any form of worldwide communication. Humans have been reduced to a tribal level, struggling for resources and shelter amid the ruins of their grandfathers’ cities.

Chapter is a shining beacon, a counterpoint to the madness that gripped the world. In the mountains of the northwest United States, a group of determined survivors dug deep and hid well. They weathered the [[Butchers]], and the [[Ghosts]], and [[the War]]. They lived in the dark and stayed quiet, a full generation surviving as best they could underground.

In the bunkers under the cliffs, they had stashed thousands of books -- a veritable treasure trove of the world before. The founders of Chapter knew that in The After, the words in those books would be the only thing saving their descendants from a life of primitive savagery. The libraries were guarded and protected better than any man or woman of the community. The books came first - the words of the old world were paramount.

Now, after [[the Breaking]], the [[Elder Council]] of Chapter has deemed it safe enough to begin rebuilding. They’ve supervised the beginnings of a town in their cliffside valley. Their scouts have spread throughout the [[Wind River Valley]], bearing messages of prosperity through trade and knowledge. The Elder Council would dole out the knowledge of the Great Archive in return for peace and kinship.

![](https://i.imgur.com/ClgJML5.png)