---
aliases: Daniel
tags: Location
---
# Village of Daniel
### Location
Located to the west of [[Chapter]] and north of [[Blackgold Station]].

### Description
Founded by people from [[Chapter]] as a pious community. All community members are part of the [[Sacellum of Light]] who believe that [[Gifted|the Gifted]] are touched by God, angels given to Earth to lead humanity forward.

### Places

### NPCs
- [[Vicar Sheila Preston]]
- [[Ginny Benham]]
- [[Doc Fisher]]
- [[Miss Rachel]] 
