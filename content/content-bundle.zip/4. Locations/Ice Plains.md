---
tags: Location
---
# Ice Plains
### Location
Located to the west of [[Highway Market]] and [[Sweetwater]].

### Description
 The region can be seen from miles away with its ever-present grey clouds and snow-choked landscape. A lot of Breach energy is at work here.
 
### Places


### NPCs