---
tags: Location
---
# Cloudhaven
### Location
Near the [[Hanging Rocks]].
### Description
A [[Helot]] village.

### Places

### NPCs