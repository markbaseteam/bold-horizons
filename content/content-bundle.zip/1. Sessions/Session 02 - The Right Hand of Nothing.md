---
sessiondate: 2021-12-22
sessionyear: 2021
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 02 - The Right Hand of Nothing
**Date:** 2021-12-22

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events
It is late autumn in the one thousand person and growing town of [[Chapter]] in the heart of the [[Wind River Valley]]. Chapter has a watermelon-sized shard called [[The Hearth|the Hearth]] that makes it warmer for a few miles around the town and cuts the wind speeds in half. (Serious wind chill once you get away from the town). The sky is iron grey with signs that the season’s first snowfall will be coming soon. A few months have passed since the events with the [[Phoenix State]] across the mountains on the eastern edge of the valley. Our heroes have felt a subtle, positive shift in the town and how they are treated. (All have Reputation 1). The 1,000 in salvage they divided up has allowed them to trade for little items. The town is deep into harvest time so most people are working that.

[[Masha Richards|Masha]] has started studying with [[Librarian Refta]]. Refta is less experienced than [[Librarian Jones]] was so the lessons have been inconsistent and the irritable Refta often tasks Masha with trudging deep into the [[Old Mines]] where the [[Grand Library]] is secured under armed guard. Masha works to copy whatever texts Refta selects. These copies are taken to a secret “[[Second Library]]” to protect the knowledge should the Grand Library ever be taken or damaged. Masha knows that finding books is of high value to [[Librarians]], especially titles not currently in the library. [[Allie Morgan]] is the Chief Librarian though she hasn’t had time to spend with Masha due to her work with the [[Elder Council]].  
  
[[Glurk]] has been working with the [[Chapter Militia]] mostly sparring with them and letting them develop their group tactics. It’s always a good workout and you’ve become friends with a couple of the Militia men: [[Serro the Dancer]] who is fast moving but ‘scrawny’ and [[Old Paal]] who doesn’t say much but will pay for beer sometimes. [[Big Jim Haggart]] is the leader of the Militia. He visited with Glurk one evening and talked about how important it is to protect [[Chapter]] and its people, in whatever ways are needed. He asked Glurk, man to man, if Glurk was devoted to the Chapter community. He emphatically answered, "Glurk devoted, Glurk protect!"   
  
[[Karx]] has been scouting to the East, in the mountains and the pass you used to cross to reach [[Old Lander]], watching for any sign that the [[Phoenix State]] left anyone behind or they knew where you came from. You even ventured into [[Old Lander]] one more time, verifying that the generator, fuel and weapons cache was still secure there. You recently returned to [[Chapter]], trying to decide if he wanted to accept the offer to hole up in the town for the winter or not.  
  
[[Garth Hernandez|Garth]] had an opportunity to get out of town and avoid the consequences of failing [[Otis]] and his offer. He signed on with [[Tilly Muscall]] and her mule train hauling trade goods to the [[Highway Market]]. Tilly avoids [[Blackgold Station|Blackgold]] like her life depended on it which suited him just fine. A couple months ‘away’ hopefully let things cool down. He got back with Tilly a couple weeks ago and has been trying to decide what to do since. Tilly doesn’t pay much and isn’t looking for a partner but it would be steady work with someone who knows more card games than even the [[Librarians]].

### Early Winter, 2139 A.D.  

Rumors fly of settlements east of town have been attacked. The [[Chapter Militia|Militia]], the PCs, and others are called up by [[Big Jim Haggart|Big Jim]] and head out to stop the threat. The PCs encounter [[Father Obadiah Blank]], his demented sons, and several villagers.  

The first snowstorm of the year struck the [[Wind River Valley]] to join the storm that was [[Father Obadiah Blank]] in visiting disaster upon the inhabitants. [[Molly Kent]], a girl from a homestead east of [[Chapter]], ran to the town to warn people about Father Blank and get help for her family. Our heroes joined with the [[Chapter Militia]] and headed east into the mountains. After encountering another victim of Father Blank, they came upon a gallowed man trapped to kill them. The explosion triggered a landslide killed almost all the militia men and all the horses. Our heroes helped two militiamen survive the torrent of rocks, [[Mac Hadrool]] and [[Bull Polloc]].
  
Having heard gunshots and screaming carried on the wind, they pushed forward up to [[Hazelwood]], a small mining settlement. [[Father Obadiah Blank|Father Blank]] and his slack-jawed followers had control of Hazelwood. Blank was exhorting the remaining resisters to join his [[Church of the Big Nothing]] in the main lodge while his hideous sons loitered and lurked nearby. [[Meeka]] snuck in in a moment of distraction for the guards and walked up to one of the miners, quickly aping the man's task of tossing books or papers into one of the burning huts. [[Glurk]], [[Karx]], and [[Garth Hernandez|Garth]] snuck up on the gate guards, killing one and knocking out the other. As the alarm was raised, more 'converted' locals attacked our heroes though ineffectually.  
  
Eventually, [[Father Obadiah Blank|Father Blank]] emerged from the Lodge to put an end to the ruckus and welcome new members to his flock. After a vicious fight, our heroes slew him. Quickly, the fog of obedience Blank had woven in the locals dissipated. Our heroes were given the finest surviving beds in the settlement as well as hot food and beer to wait out the storm. During their time in [[Hazelwood]], they learned that Father Blank used to be a simple preacher and tinker but he entered a [[Breach Zone]]. When he returned, he was on a mission, declaring that all writing was evil. The book he carried was blank to represent that writing is heresy.  
  
Blank's son, [[Mordechai]], shot like a coward from shadow and cover and fled when his father was killed. [[Malachai]] was a hand-fighter and died fighting [[Glurk]].  
  
Upon returning to [[Chapter]] in sadness for those who were lost but also celebration for ending the threat of [[Father Obadiah Blank|Father Blank]], our heroes were told the town would build them a [[Companions Cabin|log cabin]] house for the five of them to live in with food and supplies for the winter.
  
All PCs at 2 Advances. All PCs at Reputation 2.

##### Navigation
[[Session 01 - Shadow of the Phoenix]] | [[Bold Horizons]] | [[Session 03 - The Trials of Ascension]]

