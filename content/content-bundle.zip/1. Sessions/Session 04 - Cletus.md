---
sessiondate: 2023-01-12
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 04 - Cletus
**Date:** 2023-01-12

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events
**April 2140 A.D.**

### Summary

### Garth's Thoughts

[[Garth Hernandez|Garth]] walked out of the [[Companions Cabin|cabin]] wondering why he was still irritated with [[Allie Morgan]]. Maybe it was [[The Verdant]] wine that [[Meeka]] had been so fond of.  He'd been fond of it as well. But Allie only poured the one glass before changing to the more common [[Chapter]] vintage.  

He'd pitched his idea of setting up a trade route between Chapter and [[Cloudhaven]]. He'd expected her to be interested since he thought Cloudhaven was why she'd invited the group to her lab. But instead, she'd been indifferent about the whole thing. That by itself wasn't a big deal.  He hadn't expect her to offer to support it directly.  

But then she mentioned that it would good for Chapter if they got any fuel sources from the [[Ghosts|Ghost]] ship that had crashed there.  "Gee you think?  Like maybe establishing trade with the [[Helot|Helots]] there would help with that.  Then you could actually know what comes out of the ship.  Be on good terms with them so they give you the fuel instead of say, [[Blackgold Station|Blackgold]]."  He thought all that but said nothing.  Pissing off Allie Morgan was no way to about life in Chapter.

He was already out of the [[The Blue Sky Tavern]] before he was pulled out of his thoughts.  More homesteaders had come to town to petition [[Elder Council|the Council]] for land to set up farms.  He recognized one face in the crowd though that wasn't a homesteader.  [[Cletus]] was scavenger and salvager.  

Garth watched him just long enough to figure out he was going to [[Big Bill's Bar|Big Bill's]].  Then he continued on to [[Kree Daniel|Kree's]].  [[Shandra Pierce|Shandra]] had some of the sweet bread today that her grandmother liked.  He knew he'd still just get a cold stare from the old woman, but figured eventually she would warm up to him.  At least that was the plan.

He'd been thinking of trying to get a couple of horses and a wagon and making a quick trip to [[Village of Daniel|Daniel]] and back.  And he'd need stuff to trade of course.  That would probably be the easy part though.

He wasn't sure the old woman would let Kree go with him, but it was worth asking.  Just probably not today.

### Meeka's Meanderings

Meeka was beyond excited as she held the first cleat she had just acquired from the trader they had met at their cabin. She was convinced that with just this one cleat, she could play baseball and become the greatest player in all of Chapter. Her thoughts were as distorted and colorful as her acrobatics, and she couldn't help but share them with her adventuring party, Garth, Glurk, Karx, and Masha.

Meeka hopped around on one leg, trying to imagine what it would be like to play baseball with just one cleat. "I wonder if the players back then had one leg or three legs," she mused. "Maybe they didn't need the other cleat because they had a third leg to balance on." Her friends exchanged glances, trying to keep up with Meeka's imaginative mind.

Meeka was also curious about the different positions on the field. "I heard there was a position called left field. Do you think that's where you go when you're way out?" She looked down at her feet, pondering what color socks the players might have worn. "I heard that there were sock people that played," she said, looking at her own socks. "Maybe the blue socks were the best players."

Her thoughts then turned to the mystery surrounding the game of baseball. "I remember hearing that the biggest question back then was, 'Who's on first?' So, does that mean right field was the most important?" she wondered. The group continued their journey with the merchant and his mule, but Meeka couldn't shake her thoughts about baseball. She was determined to find the other cleat so that she could play.

Meeka pestering Karx to find the other cleat became a common occurrence as they traveled. "Can you track this other cleat? I mean, it's just one shoe. It has to be easy to see a one cleat track," she said, bouncing up and down on one leg. "Do you think it's just a one-legged player since they didn't need the other shoe?"

Meeka's thoughts were all over the place, but her excitement was contagious. "Maybe it was a change like you, with three feet, so it didn't need that cleat," she said, looking at Glurk. "And I wonder what color socks they wore. I heard that there was a big deal made about the color of socks back then."

Her friends continued to humor her, listening to her musings about baseball and other strange things. "I heard there was a tape called Sweating to the Moldies," she said, making a reference to a mystery that had always intrigued her. "And what about ferals? I heard there was a lion's den where the baseball games were played."

Despite her friends' confusion, Meeka remained determined to play baseball and become the greatest player in all of Chapter. And so, when she spotted one of the ferals wielding a baseball bat, she rushed over and claimed it as her own. "This is the greatest day ever!" she exclaimed, holding the bat with a huge grin on her face.

Meeka's thoughts on baseball might have been distorted, but her excitement and determination were contagious, in her mind anyway.

## Notes
- [[Meeka]] 
	- [[Changed]] woman named [[Emily]]
	- Upset with [[Meeka]] 
	- She is short and wants to be a mother 
	- Pain resistant (Major)
	- Limited Telepathy
	- Born Healer
- [[Glurk]] 
	- Male named [[Gus]]
	- near family, but rivals
	- bright and wants to save the world
- [[Karx]] 
	- [[Changed]] woman named [[Maude]]
	- part of group called [[The Posthumans]] 
	- good friends
	- she thin as rail and wants to be rich 
- [[Garth Hernandez|Garth]] 
	- woman named [[Lydia]]
	- she lives in the same house Garth used to live 
	- acquaintances
	- she is fearless and wants to be more powerful
- April and winter winds are starting to abate
- Old Man Rico passed away, [[Masha Richards|Masha]] had given him books to scribe
- homesteaders have been coming to ask [[Elder Council|the Council]] to set up in and around [[Chapter]] 
- [[Chapter Militia|Militia]] had fought off some [[Ferals|Feral]] raiders
- Freedom Day - April 30th
	- Date the aliens left in 2090
- [[Allie Morgan]] 
	- Chief [[Librarians|Librarian]]
	- has lighted and guarded lab
	- invites the group 
	- looks like workshop with people working
	- people working on [[Ghost Shard]]
	- offers wine from [[The Verdant]]
- [[Garth Hernandez|Garth]] tells her he wants to set up consistent trade with [[Hanging Rocks]] 
- man named [[Cletus]] arrives in [[Chapter]] 
	- talking to [[Barnabus Quill]]
	- has salvage
	- has an Old World coffee thermos with the letters SA that is in really good shape
	- doesn't want to talk about it
	- is going to pass out at [[Big Bill's Bar]]
	- Garth takes him back to the cabin to rest
	- Meeka wants to go through his stuff, but Garth says that would be wrong
	- then [[Garth Hernandez|Garth]] steps outside to leave [[Meeka]] alone with predictable results
	- among other things, has a copy of the 1984 novel in his salvage sacks
	- all in good shape 
	- Meeka wants an orange shoe that she thinks is a baseball cleat
- [[Barnabus Quill]] wants group to go and get salvage it is 4 days to the nw
	- sending [[Brant]] and [[Evers]] along as well
- [[Garth Hernandez|Garth]] asks Cletus about Miss Rachel
	- she lives in [[Village of Daniel|Daniel]] 
	- wanted to marry but she married a rich man so he wants to be rich 
- attacked by moldie [[Ferals]]
	- Cletus is vicious defending his mule, [[Cletus|Dorothy]]
	- the Ferals try to grab and shock, succeed on [[Brant]] and he collapses
	- [[Meeka]] is convinced the club one of them has is a baseball bat
	- kill several Ferals and the rest run
	- Brant is able to pull through 

##### Navigation
[[Session 03 - The Trials of Ascension]] | [[Bold Horizons]] | [[Session 05 - NASA Ship]]

