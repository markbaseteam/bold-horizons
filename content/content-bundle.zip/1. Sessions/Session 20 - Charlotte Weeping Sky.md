---
sessiondate: 2023-11-09
sessionyear: 2023
campaign: Bold Horizons
tags:
  - session
  - AfterSession
  - nolog
setting: The After
---
# Session 20 - Charlotte Weeping Sky
**Date:** 2023-11-09

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- Still with [[The Tribe]] 
	- [[Charlotte Weeping Sky]] comes into the camp 
	- Glurk notices she is ignored by the tribals 
	- she asks about his arm and says she knows someone that might be able to help 
	- Wants the group escort her back to her people, but to be subtle about it 
- Garth asks her where they are going, going to see her Uncle 
	- He is an inventor and studies science
	- Not seen as tribal material 
	- He doesn’t use [[Ghosts|Ghost]] or [[Butchers|Butcher]] tech, but uses his knowledge of the old world 
	- Lefty asks as well and she says her uncle might be able to help since Lefty lost the arm doing a good deed (saving a child)
- She was born in the tribe, her family is still with them, but don’t approve of the uncle 
	- She was involved in a fight with a [[Butcher Bear]] 
	- Barnabus asks why she isn’t like by the tribe, ended up on the wrong side of some arguments 
- Next day come to a river that needs to be crossed, would come up to lower chest if walking 
	- Garth and Lefty at the front notice that [[Charlotte Weeping Sky]] seems sound asleep
	- Yells at her and shakes her but she doesn’t wake up
	- Garth leads her back to the shallows, but then Garth and Lefty dismount and walk into the river 
- Masha asks what is going on and they both say they are going to take a dip 
	- Barnabus moves up and wraps a rope around Lefty 
	- Lefty teleports away and Garth starts floating 
	- Masha makes an incredible shot on the leader and hits despite cover and magic protections 
	- [[Half-Assed Tony]] shot and falls off his horse
	- Charlotte shot and wakes up 
	- Barnabus kills one that attacked Masha 
	- Glurk goes to an island and attacks 
	- Lefty snaps out of it and teleports himself and Garth back to shore 
	- Barnabus swings at one of them (stress tag on Lola)
	- Adventure Card:  Here Comes the Cavalry
	- the one Glurk attacked jumps into the river 
	- Lefty casts Blind on Garth to confuse him to keep him from going back to the river 
	- Glurk jumps into the river and lands on one of them, knocking it out 
	- Masha tackles Garth 
	- Hear volleys of gunfire, but no bullets at the group
	- Barnabus attacks again and Mavis phases out of reality momentarily (stress tag)
	- Lefty casts Burst on one on one of the islands, causing the attack to disappear into [[Breach Zone|the Breach]] 
	- Charlotte helps [[Half-Assed Tony]] 
	- [[Barnabus]] throws an axe (stress tag)
	- Glurk catches up with the leader, Blind Raven 
	- Blind Raven tries to bolt him but no damage 
	- Glurk fights Blind Raven for a couple of miles down the river and kills him 
	- Edgar Tall Sky, Charlotte’s uncle, arrived with a mechanical contraption with multiple guns 
- Charlotte says they were Tribal Exiles 
	- she was instrumental in getting Blind Raven exiled
	- One of the Exiles was with Charlotte when the Butcher Bear attacked and was getting mechanical arm and leg, which she hated 
	- So they wanted to kill Charlotte 
- Go to Edgar’s place, lots of salvage and experiments
	- Wants to create an android, but doesn’t know how 
	- Makes a mechanical arm for Glurk 
	- Will be here for a couple of days for Glurk to heal 
	- Lefty is not interested in getting an arm 
##### Navigation
[[Session 19 - Blood Howlers]] | [[Bold Horizons]] | [[Session 21 - Tracking Big Jim]]

