---
sessiondate: 2023-05-24
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 11 - Heroes of Daniel
**Date:** 2023-05-24

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- hear a scream from the breech zone and look back the sky is different 
- head back to [[Village of Daniel|Daniel]] 
- hear the moans of the people trapped in their nightmares
- see a man walking with a lot of blankets
	- [[Barnabus]] is putting blankets on people 
	- bodies in the streets he said died in terror 
- go to the church to check on [[Meeka]], she has died 
- more died in the church as well 
- Glurk sees a wave of the breech energy come through out of the corner of his eye, Garth feels something but doesn't see it 
- Masha goes up to the tower and looks around, sees a pulsing golden white light in the direction of the cabin 
- Lefty says he can sometimes hear Nathan, a young boy that was lost in a [[Breach Zone]] 
- Garth checks for [[Vicar Sheila Preston|Vicar Sheila]], [[Sister Wilma]] and [[Gavin Trent]], they are all sick but alive
- Masha sees the golden light disappears and a person walking out of the woods
	- the golden light is following the person 
	- the light is the archangel 
- the person walking is [[Karx]], but not covering his spikes 
	- never would have done that 
- group debates if should attack the archangel 
- [[Lefty]] casts Smite on everyone and run towards where the angel is coming from 
- archangel is talking as he approaches
	- "I am God's wrath. I speak with God's voice. I embrace the worthy as gentle lambs... and I judge the wicked... HARSHLY."
	- archangel floats to Garth and asks if he has decided to repent, Garth says he has come to lead him to the church 
	- "The Lord our God has chosen this day to bless the faithful and lead the sinners to redemption through confession or the holy fire. I am God's champion and will strike down the evil and unrepentant. These visions are what is to come without redemption, without salvation. Follow the path of Righteousness!"
- Lefty blasts the angel 
- [[Barnabus]] kills Karx 
- Barnabus hits the angel with Lola
- Masha kills the archangel and the face momentarily looks like [[Clinton Moss]] 
	- the chest cracks open and there is a [[Ghost Shard]] where the heart would be
- turns into day, like 10am, and things seem normal
- Lefty takes the shard 
- burn the body of the archangel 
- people come out of the church, including [[Vicar Sheila Preston|Vicar Sheila]] who is healing people 
- about half the population town is lost
- people moving around quicker than would be expect, but very thankful to be able to move 
- Garth blames [[Clinton Moss]] as a demon and when he was killed the area returned to normal 
	- shows the writing inside his wagon as demonic
- Masha tells she will take the wagon
- Vicar Shelia blesses everyone and asks any are interested in taking a farm and being members of the community 
	- "We are most grateful for the aid you brought us and the great evil you stood against to save us. You are all blessed." 
	- [[Barnabus]] and [[Lefty]] take the offer
- Glurk, Masha, and Garth 
	- [[Sister Wilma]] offers a pistol 
	- Garth is allowed to trade and asked about staying with [[Ginny Benham]] 
	- Masha given permission to read any texts and hear their stories
	- will pray for Glurk's arm to heal 
	- will tell [[Bishop Gabriel]] about it 
- Jerimah will stay in Daniel 
- want to name the camping area behind the church 
- heading to Chapter and Lefty and Barnabus going along 
	- see a plume of smoke in the direction of [[Chapter]] 

Get an advance, up to 6

##### Navigation
[[Session 10 - Archangel]] | [[Bold Horizons]] | [[Session 12 - Chapter on Fire]]

