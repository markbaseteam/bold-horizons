---
sessiondate: 2023-06-07
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 12 - Chapter on Fire
**Date:** 2023-06-07

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events

![](https://i.imgur.com/OvXWQfS.png)

### Notes 
- head south to the Western Road that leads to [[Chapter]] 
- about an hour away from there and see smoke 
	- large group of riders coming from town and it is the [[Chapter Militia|Militia]] 
	- tell Glurk to get there and be in charge 
- [[Chapter Public Stables]], [[Allie Morgan's Laboratory]], and [[Council House]] are on fire 
- Masha and Lefty pick up stress tags trying to figure out what is going on
	- Masha - All Thumbs hindrance
	- Lefty - Hesitant hindrance
- Barnabus doesn't think the fire is acting normal, it isn't spreading beyond a defined area 
	- dirt, flour, and water haven't put it out
	- suggests using a chemical and [[Silas and Demerius Rook|Silas Rook]] helps make something that does put the fires out
- [[Otis]] says must have been other traders that were in town 
	- he had been showing them around and says they left about a half-hour before the [[Chapter Militia|Militia]] left 

**Otis**
![](https://i.imgur.com/gpa5fbP.png)
- Masha notices [[Old Man Crow]] at the [[Council House]]
	- he motions her over and shows her a bullet riddled body in the Council House 
	- he doesn't think the people that started the fire have all left 
	- he doesn't know how the person is, but what he has heard lines up in part with Otis said 
	- only one of the traders did any talking 
	- sold some books to [[Allie Morgan]] 
	- there is a mask and cloak beside the body 
	- Masha examines the body and notices it has a green oily film like the [[Phoenix State]] at [[Old Lander]] 
- Garth tells Glurk he needs to send out a rider after [[Big Jim Haggart|Big Jim]] since he is probably going the wrong way 
- Allie tells Masha that [[Pentos]] was the spokesman for the cloaked traders
	- she purchased three books from him, two newly written out copies from the before times
	- partial copy of Rand McNally Atlas and a copy of Lolita 
	- "A New Dawn Rises" by Maximillian Kampf a new written out copy but Allie didn't read it
- Barnabus is watching the town who is watching him to see if any don't seem normal  
- Garth and Lefty take [[Meeka|Meeka's]] body to the [[Skav Burrow]] 
	- ask them to keep an eye out
- Barnabus on patrol
- Masha goes to the [[Mama Carolla's Boarding House]] 
	- none of them spoke and do see the green oil 
- Garth and Lefty find a couple that was saying the traders had left, but they realize they were just parroting Otis 
- Barnabus still on patrol 
- Masha tries to check on the mines and there is no one guarding the [[Mine Entrance]] 
	- sends a kid off to find Garth while her and Barnabus keep an eye on it 
- Go check it out and the gates are closed but not barred 
- go through the gate and find two bodies of assistants 
- come across another body further on, [[Librarian Aleph]] an older 
- go up to the water power and armory 
- Garth thinks he hears something from where they just came from 
- Barnabus sneaks back down but has a coughing fit 
	- unknown stress tag 
- Garth sneaks back as well 
- hear something towards the library 
- sneak over that way and Barnabus thinks there is someone hiding in the area beyond 
- Lefty reaches into [[Breach Zone|the Breach]] and calls forth energy that surrounds everyone (deflection)
- Masha tries to look further into the library and her spear catches on the floor 
	- unknown stress tag 
- Barnabus and Garth take out a trader guard, Barnabus with a big hit with Lola 
- Masha moves forward and finds another trader who shoots her with a sub-machine gun 
- Lefty comes up and fries it with a Burst 
- the last trader shoots at Masha but misses
- Lefty traps him in a Breech barrier
- Garth tells the trader to surrender, but he tries to kill himself instead
	- the gun jams and he is unable to stab himself 
	- he tells the story 
	- (Adventure Cards)
- find the [[Librarians]] locked in a storeroom 

##### Navigation
[[Session 11 - Heroes of Daniel]] | [[Bold Horizons]] | [[Session 13 - After the Phoenix State]]

