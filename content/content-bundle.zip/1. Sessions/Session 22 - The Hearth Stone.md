---
sessiondate: 2023-12-20
sessionyear: 2023
campaign: Bold Horizons
tags:
  - session
  - AfterSession
  - nolog
setting: The After
---
# Session 22 - The Hearth Stone
**Date:** 2023-12-20

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- Lefty and Nathan disappear from the [[Breach Zone]] 
- Garth, Glurk, Barnabus, and Masha are in the zone with Rex 
- Hear a bellow of something large nearby to the southeast
- *This breach zone is similar to the land you were just standing in but here it is all wasting away. It isn't literally tree for tree but a forested area is now only black, skeletal tree trunks and barren limbs over ashen ground. The light is murky, like a winter twilight threatening to go dark. It is quiet, devoid of leaves rustling in the wind, insects, birds, or other natural noises. Light winds come through at times, stirring up clouds of ash and dust making visibility difficult and breathing hard unless you are masked.*
- Cloud of ash is getting closer, group moves to the north and tries to move around some rocks 
- Lefty tries to open the breach again, but there is resistance
- Ash giant appears and smashes Rex with his club 
	- *Out of the shadows lumbers a giant of a man, ten or twelve feet tall and adorned with metal from the Old World as a kind of armor. There is Yield Sign, Children at Play, guardrails, manhole covers, and more. The armor is rigged a bit precariously on  strip of some kind of grey leather. It is dragging a tree trunk in its right hand like a massive club. In its left it is hauling a piece of heavy iron grating some 3 feet by 5 feet like shield. It is growling nonsense words but clearly angry. It thumps forward, making the ground tremble…*
- Glurk chargers forward and smashes the giant with his hammer, killing it 
- Glurk and Garth see a shimmer in the air as Lefty starts opening up the breach 
- Garth yells for Kree and Masha to get the horses and get to the opening 
- Lefty says people need to be touching him or touching someone that is touching him to get back to the normal world 
- Nathan is there as well 
- Lefty is very tired and has an affinity for [[The Hearth|the Hearth]] stone 
- Bury [[Big Jim Haggart|Big Jim]] and the other [[Chapter Militia|Militia]] members that aren’t in the breach near the campsite 
- Get back to [[Chapter]] and there is a lot more activity than when the group had left, including some people getting ready to leave 
	- Go to [[Allie Morgan's Laboratory]]
	- Hear rumors that [[Phoenix State]] has killed [[Samuel the Grip]] and are perhaps days away, they have left [[Blackgold Station]] 
- tell Allie about [[Breach Zone|the Breach]] and Lefty mentions possibly trying to trap the Phoenix State in a breach 
	- She tells him he is probably the one that would hav to do it, since someone else might get a different result 
- [[Gregori]] had gathered a group of around ten [[Chapter Militia|Militia]] and left on a mission, but no one on [[Elder Council|the Council]] knows where he went
	- Short of defense currently 
	- Asks Glurk to take charge of the militia 
- ask Allie about [[Samuel the Grip]] and she believes the rumors 
	- Phoenix State either working with Blackgold or took what they needed, so they seem to be refueled
	- Lots of ATV, some trucks, infrantry, and what sounds like a couple of tanks 
- Allie wants to present the breach idea at a council meeting 
- Lefty goes to [[Old Man Crow|Old Man Crow’s]] cabin to check on the fatigue 
	- Garth goes with and so does Nathan 
	- Lefty tells his story and that of Nathan 
	- Old Man Crow says he can try to help Lefty but will take time, weeks maybe 
- Go to [[Elder Council|the Council]] meeting 
	- Allie explains that Big Jim had stolen [[The Hearth|the Hearth]] and that the group was sent to retrieve it 
	- She says it will start working again 
- Lefty mentions his plan and telling the story of Nathan falling into a breach zone 
	- [[Xelia]] again says should go to bunker 
	- Allie says it is desperate times and this is the best option 
	- Council is convinced and discussion moves to what we people going to be told 
	- Decide to not say anything in case of spies, which they believe [[Gregori]] was 
- Garth and Barnabus scout ahead and set up the explosions 
	- Garth also finds a culvert that he had hidden from [[Ferals]] past for Lefty to hide in 
- Masha works with [[The Star League]] to make an amplification device to make sounds to scare the ones that remain 
- Nathan stays with Masha 
- Lefty opens [[Breach Zone|the Breach]], a couple of soldiers see him and take shots but miss 
	- Lefty summons a double to taught the soldiers and then closes [[Breach Zone|the Breach]] 
	- He comes out of the culvert and doesn’t see any [[Phoenix State]] at all 
#### Aftermath 
- Garth and Glurk on the Council 
- Garth looks to consolidate Samuel’s network under him and trying to figure out how to clear the pass to the west 
- Glurk in charge of the [[Chapter Militia|Militia]] and funds for the [[Chapter Militia|Militia]] 
- Barnabus asks for land and a cabin inside the walls 
- Lefty also asks for land and a cabin inside the walls 
- [[Old Man Crow]] asks Lefty to visit with him more, doesn’t seem long for this world and wants to pass things on 
- Masha asks for a cabin inside the walls, library privileges, and a stipend to do what she wants 

##### Navigation
[[Session 21 - Tracking Big Jim]] | [[Bold Horizons]] | TBD
