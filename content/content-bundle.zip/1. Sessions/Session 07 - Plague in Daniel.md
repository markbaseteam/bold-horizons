---
sessiondate: 2023-03-09
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 07 - Plague in Daniel
**Date:** 2023-03-09

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events
### Summary 

The Companions were asked a lot about the attack by the [[Mighty Ochre]].  Meeka's story changed constantly, while Garth tried to make sure everyone was getting credit not just the [[Chapter Militia|Militia]].  

[[Big Jim Haggart|Big Jim]] made Glurk a sergeant and asked him to try and recruit Karx into the Militia.  Karx said he was only interested in joining the [[Scouting Guild]].

[[The Star League]] asked Garth to join them and he said he'd think about it.  He did make a deal with them that they have first rights to buy any salvage or trade goods he came across though.  

Masha was asked to interview a potential new [[Librarians|Librarian]].  The girl's family was local farm laborers.  Masha decided she needed more schooling and set that up for her.

Karx came across a friend from the Scouting Guild, [[Cliff Westley]].  Westley told him there were signs of potential plague in [[Village of Daniel|Daniel]].  

Garth took the information to [[Bishop Gabriel]].  He got a deal on medical supplies from the [[Sacellum of Light]] and convinced the rest of the Companions to pitch in for a wagon and two mules.  

On the trip to Daniel, they came across an area where the weeds has turned purple.  The mules wanted to eat there, but Masha said it was unsafe.

Garth went into town first.  He got nervous after seeing [[Vicar Sheila Preston|Vicar Sheila]] really was sick and went back to the group.  The rest then went into town to investigate.

From [[Sister Wilma]] and [[Gavin Trent]], a Watchman, they learned that  people of the town started having terrible nightmares about three weeks ago.  The nightmares played on the person's fears.

They also found that a man named [[Clinton Moss]] was selling a "cure."  Calling it [[Moss's Magnificent Miracle Medicine]], he had convinced the townspeople that it was their only chance.  It allowed the people to sleep through the night.  The Companions weren't as sure, but Masha's investigation of the herbs revealed they were normal.  

### Notes 
- people ask about the [[Session 06 - The Mighty Ochre|Battle of Moldie Mountain]] 
	- Meeka tells lots of different versions
	- Masha doesn't talk about it much and refers people to others 
	- Karx tries to tell it about the trip there and back and not the fight 
	- Glurk accepts credit 
	- Garth tells it so he doesn't contradict [[Big Jim Haggart|Big Jim]] but makes sure other people get credit 
- go to [[Armstrong House]] and meet with [[Barnabus Quill]] 
	- ask Garth to stay later and join [[The Star League]] 
	- says he'll consider it but is thinking of getting a new team together
	- Baranabus asks about a deal of first purchase rights and they shake 
- Glurk is at the [[Chapter Barracks|Barracks]] and Big Jim asks him out for  a drink 
	- never invited him out before 
	- says it is important for the people to hear about the bravery 
	- offers to make Glurk a sergeant 
	- Glurk is the 3rd sergeant 
	- Big Jim asks Glurk to ask Karx to join the militia 
- Meeka sees people playing soccer and joins in 
- Glurk asks Karx and Karx says no, feels serves Chapter better in the wilderness 
- Masha asked to interview a new prospective [[Librarians|Librarian]] 
	- coming from outside of Chapter 
	- Masha sets her up with schooling 
	- her family are laborers on local farms 
- Karx works on his skills (First Strike)
- Garth in energized from being back at [[Big Bill's Bar|Big Bill's]] and starts working on his trade contacts 
	- [[Kree Daniel|Kree]] loves the idea of setting up her grandmother and [[Cletus]]
	- Cletus stops talking about going on his next trip 
- Glurk gets a warhammer since can't use the halberd 
	- also asks [[The Star League|Star League]] about human tech 
- Masha helps Glurk research options for his arm 
	- also starts checking sources on Big Jim 
- Meeka wants to find a cape 
	- also gives [[Kate Runahan|Goodtime Kate]] a gift 
- Karx sees [[Cliff Westley]] heading into town 
	- was someone that encouraged Karx that he could become a scout 
	- seems worried
	- was in [[The Verdant]] and headed to [[Village of Daniel|Daniel]] 
	- saw trail sign saying there was plague at the village and everything looked boarded up 
- Garth asks [[Bishop Gabriel]] if he had any info on a possible plague but he hadn't
	- offers to investigate if Gabriel will help outfit 
	- gets medical supplies cheaper to trade
- Masha gets [[Mercy Hospital]] to send Jeremiah with them 
- get two mules and a wagon, everyone throws in equal shares 
- [[Cliff Westley|Westley]] shows Karx a route most people don't use 
- [[Sister Wilma]] 
- [[Gavin Trent]], Daniel Watchman 
- 3 weeks ago started nightmares that played on people's fears 
- “That trader, Mr. Moss, brought in a load of herbs he’s distilling into medicine. [[Moss's Magnificent Miracle Medicine]], he calls it. It’s the only thing that lets my family sleep through the night; before that, they started moaning and shouting when the sun went down -- mostly nonsense words. Thank God for [[Clinton Moss]] and his medicine.”
- “The barns and houses that burned down all happened at night, while folk were sleeping deep, with medicine in their bellies. Lost a whole family when the Morgans’ place burned up, and none of us knew about it till the morning. Normally the Watchmen would keep an eye out and raise the alarm, but most of them have gone missing. Maybe they didn’t have the faith to see this through, and left us.”
- Plans for next time
	- Investigate upstream in the creek 
	- Talked to Clinton Moss and his miracle medicine 
	- Herbs seem normal.
	- Purple weed on the trail was four days back.
	- Creek runs through Daniel NNE to the lake.
	- Talked with Gavin the Watchman and Sister Wilma

##### Navigation
[[Session 06 - The Mighty Ochre]] | [[Bold Horizons]] | [[Session 08 - Plague Hounds]]

