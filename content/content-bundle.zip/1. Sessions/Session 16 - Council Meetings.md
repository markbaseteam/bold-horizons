---
sessiondate: 2023-08-31
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
%%
RPGGeek Link: [https://rpggeek.com/rpgitem/316956/after](https://rpggeek.com/rpgitem/316956/after)
%%
# Session 16 - Council Meetings 
**Date:** 2023-08-31

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- [[Old Man Crow]] is going to come down from his mountain to go to [[Elder Council|the Council]] meetings until a decision is made 
	- [[Samuel the Grip]] - advocating for negotiations
	- [[Bishop Gabriel]] - advocating for bunkering down 
	- [[Allie Morgan]]  - advocating for defending 
- "Team Bunker" is Old Man Crow, Bishop Gabriel, Xelia. Gabriel will speak for them. He is a gifted orator.  
- "Team Defend" is Big Jim Haggart, Allie Morgan, and Peter Black. Allie will speak for them. She is smart and attractive.  
- "Team Negotiate" is Samuel the Grip, Shaun the Broker, and Darby Morgan. The Grip will speak for them. He is a very experience negotiator
- Grip has some people visiting the prisoner to help with the language situation 
- Talk around [[Chapter]] is that the intent isn’t compatible and others argue that not enough people to do multiple things 
- Bo and Lefty go talk to [[Bishop Gabriel]] to join team defend 
	- Lefty uses [[Gifted|the Boon]] to appear to have angel wings but offends the Bishop 
	- The Bishop spreads the word that no one should talk or cooperate with the Companions, and word might get back to Daniel 
- Masha and Garth go to talk to Allie Morgan 
	- Argue that not only defend but to recruit additional villages to help 
	- Ask Allie for support to get a seat on [[Elder Council|the Council]] 
	- She agrees 
- Garth and Masha go to talk to Samuel and ask about the language situation 
	- Samuel tries to deflect but he says the plan is to learn the language to understand their deliberations 
	- Ask about support for a council seat and he says he’ll support but expects an ally 
	- Masha notices some of Samuel’s people are shifty and nervous 
	- [[Brand]] is Samuel’s right hand person, he is animated having a conversation with Samuel when they leave
- Council meeting - nine chairs with the names of the all the people that have ever sat in them serving on the council 
#### Council Meeting 
##### Opening Statements
- [[Samuel the Grip]]: "You all know me. I get things done. When the cattle got sick, I got medicines from Sweetwater. When the Ferals began to rampage, I convinced White Pine to help us cut down their numbers. We live a civilized life because we make deals and compromises. We work together with the other communities because we've convinced them that it is in their own best interests. Every group wants to survive.”
- [[Bishop Gabriel]]: "From the moment the Angels revealed themselves on Earth to rid us of the Butcher Demons, we have been held in God's hands. God led our people to the Mines and salvation. God led us out of the Mines to found this community, a Chapter in his Good Book as I always say. He provided for us with the Holy shard, giving us food, strong livestock, and temperate weather. Now in this time of trials, His Way is clear. We must return the faithful to the secure embrace of the Mines until this threat has passed."
- [[Allie Morgan]]: "There are many factors which influence the results of a conflict or battle. Numbers, logistics, supplies, morale, position, surprise, and technology. We have the greatest collection of human knowledge probably in the world. We simply need to unlock that knowledge into something we can use to stop the Phoenix State from harming Chapter or Wind River Valley. We need something that can neutralize their advantages or create disadvantages until it is untenable for them to continue their aggression. I will admit we should have been preparing better for the chance this day would come, but we have our smartest people looking for those advantages right now. I'm confident that we'll find the solution. And that solution includes reaching out to our friends in Wind River for their help.”
##### Arguments
- First Night 
	- Samuel says Allie is working towards war, but doesn’t make a lot of progress 
	- Bishop makes progress for bunker
	- Allie says Chapter is worth defending itself and not just library, doesn’t make progress 
- Second Night 
	- Garth sits in the second row of seats 
	- Samuel looks pleased with himself 
	- Bishop begins that doesn’t know if [[Phoenix State]] is coming and thinks should negotiate 
	- Allie says might have something to share the next night 
	- And ends early 
	- Big Jim is half in the bag by the time the meeting started 
- Third Night 
	- Allie goes first and reveals that the [[Librarians]] and [[The Star League|Star League]] have had a breakthrough for explosives and radio detonator as a force equalizer 
	- Samuel upstages her that he has heard from his contacts that he has a way to reach the [[Phoenix State]] and actually talk to him, Garth feels like he is telling the truth
	- Bishop seems half in with Samuel, but still argues for bunker as a precaution 
- Fourth Day 
	- Masha talks to the Helots, Skavs, and [[Xelia]].  Skavs feel they will adapt regardless.  [[Helot|Helots]] will leave if they don’t like the decision.  Xelia seems to believe that her vulnerable families will get into the bunker. Masha is making her face reality.
	- Garth goes to visit [[Old Man Crow]].  He has a few people there, feels a little like a commune. Asks for him speak to defending. 
	- Gabriel goes first and says Old Man Crow was the first one to suggest bunker. 
	- Allie explains more about the explosives and key approaches and vantage points. 
	- Grip asks how many explosives could be made?  
	- Xelia speaks, first time other than the three has spoken.  Says people needs to work on defense until an attack.
	- Old Man Crow asks if Grip would be the negotiator.  Grip agrees and has control of the room at the end.
- Fifth Night 
	- Old Man Crow speaks.  Secure the knowledge in the mines, along with the children, elder, and vulnerable.  
	- Allie needs access to her workshop, and some of them are elderly.
	- Grip 
	- Allie says has talked to [[Chapter Militia|Militia]], doesn’t mention [[Big Jim Haggart|Big Jim]].  Has been reading the manifesto, and it says they intend the conqueror and not negotiate.  Says should send a group to scout and mentions the group.
	- Grip has already sorted out the first team to meet with the [[Phoenix State]] and that he would follow.
	- Bunker 1, Negotiate 10, Defend 7.

##### Navigation
[[Session 15 - Indecision]] | [[Bold Horizons]] | [[Session 17 - Gonna Get Married]]

