---
sessiondate: 2023-04-13
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 09 - Meeka Gets Worse
**Date:** 2023-04-13

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events

- Clinton's wagon is a typical trader's wagon.  He has a variety of trade goods, salvage, and bits and pieces of old trade goods he couldn't sell in previous years. There are several bales of the purple weed that Masha saw off the trail on the way to Daniel. Scrawled on all the surfaces are weird messages in no language any of you have seen before along with apparently nonsensical diagrams.
- Masha thinks it is a formula and part of it references [[Breach Zone|Breach energy]].
	- doesn't see a shard in Moss' wagon.
- Garth asks [[Sister Wilma]] and [[Gavin Trent]] about the plague 
	- not transmitted through contact.
	- symptoms are different but all involve exhaustion and nightmares 
	- she tells Masha some people didn't take [[Moss's Magnificent Miracle Medicine]] and it seemed they died sooner 
	- but were on the fringe of [[Village of Daniel|Daniel]] as believers were taking the medicine 
- woman named [[Old Hattie]] her house burned down the night before we got there, but used to tell stories of her having nightmares about fire breathing two-headed wolves when she was a child 
- Masha going through church records
- Glurk notices the remaining livestock are on the east side of the village 
	- he finds a goat that had gone over the bridge to the far side of the village 
- Garth talks to [[Doc Fisher]] 
- Meeka sleeps and gets a lot worse 
- Garth and Masha convince the villagers to allow Meeka to stay at the church 
- Garth, Glurk, and Masha explore to the west 
- Find a run down cabin covered in weeds and thorns.  See a pink glow inside of it, reminds of the eyes of the growler.
- Glurk sneaks up and sees [[Clinton Moss]] making his medicine.

##### Navigation
[[Session 08 - Plague Hounds]] | [[Bold Horizons]] | [[Session 10 - Archangel]]

