---
sessiondate: 2023-07-06
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 13 - After the Phoenix State
**Date:** 2023-07-06

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]]

## Events
### Summary 
### Garth's Thoughts 

Garth cursed when he realized the campfire was [[Big Jim Haggart|Big Jim's]] group.  That the [[Chapter Militia|Militia]] hadn't actually ridden out after [[Barnabus Quill|Quill]] wasn't really that surprising.  But stopping this close to [[Chapter]] was pretty bold.  

He knew Big Jim could have stopped for a lot of legitimate reasons.  Lots of things could go wrong on the trail.  But he wasn't in the mood to give any benefit of the doubt.  He didn't really think the man had earned it.

The decision was to confront him or to go around him.  Garth didn't think he had to time for a confrontation though.  And he didn't want to be looking over his shoulder the rest of the way.  Best if Big Jim didn't know anyone else was out here and knew that he'd been Big Jim Laggard.  

He was grateful when only [[Half-Assed Tony]] objected.  But even he wouldn't argue that they needed to set a faster pace if they wanted to rescue [[Barnabus Quill|Quill]].

### Notes 
- [[Darby Morgan]], a member of [[Sacellum of Light]] on [[Elder Council|the Council]], leads a group in the mines checking it out.  He takes the prisoner to the prison at the [[Council House]]
- The prisoner had taken a book on chemistry and one on nuclear physics
- Masha remembers that [[Otis]] had been chatting with some of the [[Librarians]] over the last couple of weeks
- Garth and Masha go to the back entrance of the mines.  It looks like it hasn't been used, given the dust and spiderwebs
- people in town are skittish and nervous about [[Phoenix State]], though some blame [[Blackgold Station|Blackgold]] 
	- word spreads that someone was kidnapped, [[Barnabus Quill]] 
	- [[Librarians|Librarian]] Helga was killed, [[Masha Richards|Masha]] thought was kindly
	- [[Bull Polloc]] was killed trying to stop them 
- meeting at the Council House at dusk 
	- "His name is [[Septimus]]. He's from the Phoenix State east of the mountains. We know they've been out there, but we'd hoped they didn't know we were here. Apparently, we were wrong. They came here for a purpose... to steal knowledge, one way or another. The fires were a dangerous distraction. I believe Septimus when he swears he never wanted to do this but the Phoenix State forced him into service, feeding him lies about all the other communities. He now sees what he was told was wrong and deceiving. He is receiving healing and counseling from Bishop Gabriel as we speak.
	- Several Chapterians died at their hands. Give your prayers for the souls of [[Sister Helga]] and our valiant guardian, [[Bull Polloc]]. Thanks to Garth, Masha, and their friends, the Library was protected. Sadly, one of our own, Barnabus Quill, was taken captive or hostage and it appears two of the attackers escaped. Big Jim has sent militia to track them down, bring Quill home safe, and those Phoenix heathens to justice!"
- Council asks to talk to the group, meet with [[Darby Morgan|Darby]] 
	- he doesn't have any faith that Big Jim will rescue Barnabus Quill 
	- wants us to try to get him, can't let the [[Phoenix State]] have him 
	- gives us horses
- get a scout from the [[Scouting Guild]], [[Half-Assed Tony]]
- Garth says hello to [[Kree Daniel|Kree]] before heading out
- Masha and Lefty go to the [[Armstrong House]] to see if they know anything about Barnabus Quill being taken 
	- they were planning on going to the group to check if [[Karx]] could help tracking him down
	- they are very worried about what the [[Phoenix State]] will do to him 
	- ask if the group go after him 
	- they are not impressed with Big Jim either 
	- they have walkie talkies that [[Barnabus Quill]] would have and might be able to use to contact him 
- leave at dusk and head west 
	- come across Big Jim's campsite much earlier than expected 
	- skirt around it
- camp for the night and to get a short rest 
- in the morning [[Barnabus]] finds some tracks, [[Half-Assed Tony]] confirms one of the horses is extra heavy
- get to [[Hazelwood]] and have some options of paths, follow tracks 
- stop for the second night since terrain is rougher
- making decent time and make it over the pass to [[Old Lander]]  
- Masha notices the path doesn't look right, covered with leaves but only pine trees in the area.  
- yells at [[Half-Assed Tony]] to stop but he isn't able to before a bomb goes off 
	- both him and horse go down
	- [[Barnabus]] stabilizes him and the horse 
- continue on and get a gentle sloped area with waist high grass 
- [[Garth Hernandez|Garth]] feels really exposed
- no noise from the walkie talkie 
- [[Barnabus]] climbs a rock and sees movement on the other side
- group thinks are seen 
- Garth calls out no reply 
- Lefty casts Deflection and clouds the group, ride hard across the open area 
- lots of misses as group closes 
	- Garth stress tag - his horse is radiating [[Breach Zone|Breach energy]]  
- Masha, running low on bullets, get the first kill switching from burst fire to single shot 
- Lefty casts a spikey growth on Barnabus and blinds the sniper 
- [[Barnabus]] hits the sniper with both axes and the spikey growth hurts him 
- Garth convinces the soldier, a 16 year old kid, to run away
- Kill another one and Lefty blinds a second one 
- Garth tackles him and [[Barnabus]] chases down the one that ran 

##### Navigation
[[Session 12 - Chapter on Fire]] | [[Bold Horizons]] | [[Session 14 - Going to Old Lander]]

