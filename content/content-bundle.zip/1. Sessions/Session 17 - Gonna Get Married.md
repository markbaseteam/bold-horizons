---
sessiondate: 2023-09-11
sessionyear: 2023
campaign: Bold Horizons
tags:
  - session
  - AfterSession
  - nolog
setting: The After
---
# Session 17 - Bold Horizons
**Date:** 2023-09-11

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
#### Downtown 
- Glurk advances Fighting to d10
	- helps [[Old Man Crow]] to get a lead on fixing or replacing his arm 
- Barnabas picks up First Strike 
- Lefty picks powers - Teleport and Summon Ally 
	- Gets a dog 
	- Hires someone to look at his and Barnabus’ farms
- Masha bumps Agility and then Shooting and Fighting 
	- Works on status with the [[Librarians]] 
- Garth takes Fame 
	- convinces [[Kree Daniel|Kree's]] to let them get married 
	- Ceremony at the [[Council House]] 
	- Council gives Garth and Kree a house inside the walls 
#### Leave Chapter 
- Leave Chapter with fanfare 
- [[Half-Assed Tony]] coming along, recovered from his wounds 
- stay at the house that saved from [[Father Obadiah Blank|Father Blank]] 
- Next day at the entrance to the pass Masha and Lefty notice glint of metal up above on the left 
	- Lefty teleports Glurk towards the glint 
	- Shots rings out from both sides at Garth 
	- Glurk smashes one in the head on the left with his mace 
	- Garth takes a shot and then gets cover 
	- Barnabus gets cover 
	- Glurk is shot but only shaken 
	- He is shot again and goes down 
	- Barnabus climbs up the cliff hits one with an axe 
		- Gets a stress tag on the second axe 
	-  Masha moves to cover 
	- 

##### Navigation
[[Session 16 - Council Meetings]] | [[Bold Horizons]] | [[Session 18 - To Old Lander and the Tribe]]

