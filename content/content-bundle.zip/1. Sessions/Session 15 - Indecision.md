---
sessiondate: 2023-08-03
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 15 - Indecision
**Date:** 2023-08-03

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- Barnabus and Lefty are both from [[Jeremiah Creek]] to the west 
- Lefty downtime? 
	- wants to get in with the [[Sacellum of Light]], dresses in white and shows the boon 
	- [[Darby Morgan]] is a church member and Lefty makes progress with him 
	- Good number people heading to [[Village of Daniel|Daniel]] 
	- [[Bishop Gabriel]] is mostly supportive, but his influence is a little lesser as people leave 
- Lots of talk about the [[Phoenix State]] and how close they are 
	- Lots more people at the bars and drinking contraband bean fruit 
- Garth is at [[Kree Daniel|Kree's]] house for dinner 
	- Family is considering moving to [[Village of Daniel|Daniel]] 
	- Implied Kree will go unless Garth will make her an honest woman
	- Grandmother says if he can get his own cabin that is fine 
	- Asks what [[Garth Hernandez|Garth's]] plans to help [[Chapter]] 
	- Tells her about his talking with [[Elder Council|the Council]] and [[The Star League|Star League]] 
- Masha notices [[Big Jim Haggart|Big Jim]] has been lobbying hard to fortify the pass and garrison on it 
	- Council is very divided on what to do 
	- [[Old Man Crow]] hasn’t been at the meetings 
	- Big Jim has been drinking more 
- [[Gregori]] has been gaining a reputation in Chapter for helping people and holding his own, volunteers in the [[Chapter Militia|Militia]] 
	- Filled some of the void for Big Jim being absent 
- Barnabus hears that two scouts have gone to check on [[Old Lander]] but haven’t returned
	- Factions are very divided on what to do 
	- People are frightened and some of the conversations are angry 
	- he doesn’t think Daniel will stay safe if Chapter falls 
	- Thinks something drastic must be done and walling the pass isn’t it 
	- Wants to defend Chapter for practical reasons not sentimental ones 
- Garth overhears [[Leon]] saying that should take [[The Hearth|the Hearth]] to [[Sweetwater]] and buy way in, they can fight off the Phoenix State 
	- Told to f-off 
- [[White Pine]] - organized around the remnants of an Old National Guard unit, led by the [[Colonel]] 
	- Come to Chapter to trade lumber for food 
	- Have three working vehicles, two armored trucks and an APC 
	- Weren’t super welcome in Chapter, bring in bean fruit as well as raising hell 
	- Council sent someone there 
- Council deadlocked and unable to make a decision 
- Barnabus goes to the Council to lobby to pull the resources of nearby men and woman to proactively go after the Phoenix State 
	- [[Old Man Crow]] - word is he is talking about hunkering going back to the mines, seal it up if needed
	- [[Bishop Gabriel]] - only through god that people will saved and town needs to pledge itself to god and Gabriel will show how the evil is defeated
	- [[Shaun The Broker]] - more reserved, town needs to figure it out 
	- [[Allie Morgan]] and [[Peter Black]] - in league that they are a lot of guys with guns, no super villains, use tech to defend Chapter, no real path or plan 
	- [[Big Jim Haggart|Big Jim]] - fortify pass with soldiers and keep them out 
	- [[Darby Morgan]] - voice of the people that outside the walls, worried about the crops and being at the mercy of [[Sweetwater]], not enough food stores for a siege 
	- [[Samuel the Grip]] - wealthy trader, influential, relationships with people throughout [[Wind River Valley]], Phoenix State can be bought, not a fan of military conflict 
	- [[Xelia]] - young mother, advocate for the families, as well as the [[Helot|Helots]] and [[Skav|Skavs]], looking at the fallout  

##### Navigation
[[Session 14 - Going to Old Lander]] | [[Bold Horizons]] | [[Session 16 - Council Meetings]]

