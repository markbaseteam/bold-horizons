---
sessiondate: 2021-10-14
sessionyear: 2021
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 01 - Shadowof the Phoenix
**Date:** 2021-09-21

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]

## Events
Fall, 2139.  
  
[[Glurk]] the Helot, [[Garth Hernandez|Garth]] the Free Trader, [[Masha Richards|Masha]] the Librarian's Apprentice, and [[Karx]] the Changed Explorer cross the mountains east of [[Chapter]] to find disappeared explorers. In the ruins of the town of [[Old Lander]] they encounter a [[Butcher Bear]] and a camp of [[Phoenix State]] soldiers. They draw the Butcher Bear to the encampment and it wreaks havoc. 

...you trudge back toward the remains of the [[Phoenix State]] camp. The [[Butcher Bear]] is not here, though tracks and spoor say he hasn't gone far. Parts of the metal wall have been punched down or torn off. There are the sickly, oily green of Phoenix State soldier bodies, smashed or torn by the bear. There are only two dead horses so the others got away. Counting bodies, you guess that some of the soldiers survived. There aren't any with officer insignia so the leaders escaped.  
  
The radio transmitter tower is smashed up but it looks like they took the radio. The drug lab is there though everything is smashed. [[Masha Richards|Masha]] takes careful notes of what she can and finds two vials of the strange green liquid they were injecting into the soldiers. The generator and its fuel are surprisingly unharmed. The survivors couldn't take everything and they seemed to focus on papers and weapons. Probably didn't want to leave their prized weapons and ammunition behind for enemies to use against them. Still there are two more of their oily sub-machine guns there and 200 rounds of ammunition.  
  
[[Karx]] follows the horse tracks until he's sure that they are headed south, down the valley toward the big river and assumedly back to the [[Phoenix State]]. You didn't tip your hands and it set the soldiers back for months at least. Still, they'll likely be back.  
  
After scouring the campsite, you assemble the weapons, ammunition, and ten sets of kevlar body armor not shredded by the bear. Add in the generator and fuel and about 1,000 in salvage and it is quite a treasure trove. You aren't able to haul it all home so after scouting [[Old Lander]] a bit, you find a building that can still be secured. You hide the generator and fuel there along with six of the vests and two sub-machineguns with two 30-round clips each. If people from [[Chapter]] make it back here, it would be good to have a weapons cache in case they need to defend themselves.  
  
Walking back to [[Chapter]], you've got satchels with 1,000 in salvage, four kevlar vests, the weapons and ammo you confiscated personally from the soldier patrol. [[Masha Richards|Masha]] has the drug information and two samples.  
  
Walking into [[Chapter]], you get a lot of smiles. Friends come out to welcome you back and marvel at the treasures you've brought back. You're met by [[Peter Black]], a member of the [[Elder Council]]. "I had my doubts but you've done well," he says, looking at your haul like they were pelts or scalps. "I will summon the Elder Council. We must know everything that happened."  
  
By the time you've told the whole story and endured repeated questions on the details, you've eaten better than you can remember and drunk the prized [[Chapter]] beer. At first [[Garth Hernandez|Garth]] does most of the talking, as is his nature. Eventually, they are spending more time listening to [[Masha Richards|Masha]] and her careful, detailed report. The death of [[Librarian Jones]] is seen as a serious loss. The Elder Council accepts the kevlar vests as a donation for the Militia and don't mention that your group is toting some dangerous new weaponry. They do take back their hand grenades for use by the [[Chapter Militia|Militia]]. They allow you to keep the 1,000 salvage to divide up or share as you like.  
  
"[[Masha Richards|Masha]], you have done well. We will ask [[Librarian Refta]] is she will assume your instruction. She is quite busy but your education is important. If you need any help this winter, you need simply ask."  
  
"[[Glurk]], you have done well. You have protected your people with bravery. A place has been arranged for you at the [[Common House]]. I'm told it is near the fire so you will not have to worry for the winter's cold. They will feed you well."  
  
"[[Karx]], you have done well. We are told that the [[Scouting Guild]] will look favorably on you in the future and give you more jobs of importance. Continue on this path and they are sure to invite you to join their ranks. We know that you prefer to be on your own away from the town but if you ever want to come in from the cold or stock up on food supplies, you will be taken care of this winter."  
  
"[[Garth Hernandez|Garth]], you have done well. We know your goal is to resume your merchant life. If you wish to spend the winter with us, you also have a place in the [[Common House]]. When you're ready to depart, be assured you'll get some good deals to help get you started." Garth finds it hard to respond to the [[Elder Council]] as he feels the glowering stare of [[Otis]] from the shadows. Otis is not pleased that Garth failed.
  
All PCs at 1 Advance. All PCs at Reputation 1.

##### Navigation
[[Bold Horizons]] | [[Session 02 - The Right Hand of Nothing]]

