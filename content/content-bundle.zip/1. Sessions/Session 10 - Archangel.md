---
sessiondate: 2023-05-10
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 10 - Archangel
**Date:** 2023-05-10

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events

## Notes 
- The cabin 
	- the place is massively overgrown with tangled thorn bushes and hanging vines. The shutters hang slack and crooked, and the front door has long since collapsed. 
	- The smell of strange spices is stronger, and a faint, pink glow can be seen glimmering from inside the rickety cabin. 
- See a person laying on the ground (Lefty)
- Glurk notices that [[Clinton Moss]] has a breach shard 
- Masha notices something is about to happen with the cabin, the energy is increasing
- Lefty doesn't know Clinton, was traveling and felt the [[Breach Zone|Breach energy]] 
	- Can almost sense "Nathan"
	- missing his right arm but calls up a barrier (temporary see a right arm) 
- Masha looks in the door and Clinton is "holding" the glow
	- shoots him with her bow 
- Clinton's eyes get wide, then the area around is covered in fog 
- Clinton screams and the pink light changes to golden white coming from something much bigger
- an archangel steps out of the cabin with a flaming sword and attacks Glurk 
- try to attack it but it is tough 
- Garth tries to convince it to come with him to heal [[Vicar Sheila Preston|Vicar Sheila]], but the angel is unintersted 
- Lefty sends a flood of energy at it and a cherub 
	- kills the cherub and hurts the angel 
	- yells for Nathan to come out
- the cherubs kiss [[Garth Hernandez|Garth]], [[Masha Richards|Masha]], and [[Glurk]] 
- the angel attacks [[Karx]] 
- Glurk and Garth run 
- Lefty hits him with a barrier 
- Karx defends while everyone runs 
- angel tells him to confess but he refuses 

##### Navigation
[[Session 09 - Meeka Gets Worse]] | [[Bold Horizons]] | [[Session 11 - Heroes of Daniel]]

