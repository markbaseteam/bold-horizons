---
sessiondate: 2023-07-20
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 14 - Going to Old Lander
**Date:** 2023-07-20

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- Lefty notices the [[Breach Zone|Breach energy]] on the tack of Garth's horse
- tie up the two prisoners and head towards [[Old Lander]] 
- Glurk shows up on "Heavy" the biggest horse in [[Chapter]] 
	- [[Half-Assed Tony]] is alive 
	- did not pass [[Big Jim Haggart|Big Jim]] along the way 
- Garth, Masha, and Barnabus ride ahead to scout ahead.  Lefty and Glurk riding slower behind.
- See two horses, one with two riders, in between two copses of trees 
- Garth shoots both horses and everyone rides hard 
- one of the [[Phoenix State]] guys takes his knife to [[Barnabus Quill|Quill]] 
- Barnabus kills one soldier and knocks the leader 
- The leader makes a run for it, but Lefty blinds him and then melts his skin 
	- Barnabus finishes him with Lola 
	- Pentos blurts out... "Deez Kunfretta!"... before he dies.
	- He has papers in a language that isn't understood and a map showing Old Lander, the pass, and Chapter with the trails in between 
- Lefty recognizes a symbol on the map at Old Lander that is "fort" and "starting point"
- Garth, Barnabus, and Lefty head towards Old Lander and come across a soldier on the road 
	- hears the horses and goes to investigate 
	- Barnabus kills him with his two axes 
- sneak up to a rise with a good view of Old Lander
	- higher walls about five times bigger than the original [[Phoenix State]] camp, about 100 people
	- lit up 
	- open space in the center the camp with people gathered 
	- someone with a mic is working up the crowd, can't understand but seem belligerent 
	- isn't a large guy 
	- they've cleared a lot of the area around the camp 
	- some vehicles, trucks and jeeps, plus horses 
- head back toward Chapter
	- get the two prisoners and [[Half-Assed Tony]] 
- Big Jim did make it to [[Hazelwood]] and into the mountains 
	- said saw [[Barnabus Quill|Quill]] get killed by Phoenix State but couldn't recover the body 
- take Quill to the [[Council House]] to show he is alive 
	- [[Darby Morgan|Darby]], [[Allie Morgan]], and Big Jim are there 
	- Garth bypasses the Big Jim situation and lays out the threat that the Phoenix State is 
- the first prisoner is with [[Bishop Gabriel]] to administer to his soul 
- Big Jim passes off Quill as "must have seen another guy killed"
	- wants to fortify and arm the town 
- donate the weapons to Chapter but talk to Darby about considerations
- Garth hears a rumor that [[Otis]] is back at [[Blackgold Station]] 
#### Downtime 
- Group has a reputation of 5 
- Glurk 
	- helps [[Old Man Crow]] and asks about options for his arm 
	- calls in some favors and gets some custom armor 
- Barnabus 
	- explores Chapter 
	- buys a high quality axe, Mavis  
- Masha 
	- promoted herself over Big Jim 
	- develops a rival in the [[Librarians]] 
- Garth 
	- took [[Kree Daniel|Kree]] out on a camping trip 
	- talked to Darby about a possible replacement for Big Jim, Darby mentioned maybe it would be Garth 
- Lefty 

##### Navigation
[[Session 13 - After the Phoenix State]] | [[Bold Horizons]] | [[Session 15 - Indecision]]
