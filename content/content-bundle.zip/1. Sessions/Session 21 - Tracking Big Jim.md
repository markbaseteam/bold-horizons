---
sessiondate: 2023-12-07
sessionyear: 2023
campaign: Bold Horizons
tags:
  - session
  - AfterSession
  - nolog
setting: The After
---
# Session 21 - Tracking Big Jim
**Date:** 2023-12-07

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Advances 
- Glurk - Riding and Fighting
- Lefty - Power Points
- Barnabus - Quick 
- Masha - Healing and Riding
- Garth - Spirit 
### Notes 
- Timeline
	- Day 1 - [[Samuel the Grip]] left Chapter 
	- Day 5 - the group left [[Chapter]] 
	- Day 34 - the group a day away from Chapter 
- Barnabus notices the weather isn’t changing 
	- natives of Chatper wonder if [[The Hearth|the Hearth]] is not working 
- arrive at Chapter the next morning 
	- Work has been done on the walls 
	- Talk to Marvin in the fields 
	- [[Kree Daniel|Kree]] has joined the Scouting Guild 
	- [[White Pine]] will be sending people
	- [[Old Man Crow]] hasn’t been in town but people still going to his place 
	- No one has seen [[Big Jim Haggart|Big Jim]] 
- [[Darby Morgan]] comes out and is acting nervous 
	- Says want to talk at the [[Council House]] 
	- Says [[The Hearth|the Hearth]] has been stolen by [[Big Jim Haggart|Big Jim]] 
	- Big Jim has been missing for a couple of days along with a few of his trusted [[Chapter Militia|Militia]] members 
	- Only Darby and [[Allie Morgan]] know the shard is missing 
- Glurk checks around and thinks six militia members are also missing 
	- One is Spike, who is a big mouth 
- Allie is at her laboratory and dismisses her assistants
	- Says Big Jim stole it as he was one of the few people with a key to her lab 
- Lefty goes looking for Spike’s friends and convinces them he has a job for Spike 
	- Seems like they don’t know where Spike went and maybe Spike didn’t know where he is going either 
	- Spike had packed up quickly 
- Lefty talks to Gwendolyn, who really believed Big Jim’s version of everything 
	- Said people that had wronged him would change their tune soon 
- decide to check campsites the [[Chapter Militia|Militia]] used to see if maybe Big Jim would have gone there to start his travel wherever he is going 
- [[Kree Daniel|Kree]] says the first campsite was being used the night before, the group there left on foot 
- Go to the second campsite and Kree sees a tripwire 
	- Garth climbs tree and takes a shot at Big Jim, seems like a good hit but Big Jim moves at the last second 
- Lefty teleports Barnabus and Glurk into the campsite 
	- Barnabus hits Big Jim with both axes and Glurk sweeps through the group 
- Kill Big Jim and most of the militia, leave Loretta and Rex alive to get the info 
- Lefty touches [[The Hearth|the Hearth]] and says he can save Nathan
- Lefty and Garth go looking for Nathan and find him, he looks like he is the same age as when he was lost into [[Breach Zone|the Breach]] 
- Lefty’s missing arm shows a glow 

##### Navigation
[[Session 20 - Charlotte Weeping Sky]] | [[Bold Horizons]] | [[Session 22 - The Hearth Stone]]

