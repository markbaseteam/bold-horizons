---
sessiondate: 2023-02-02
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 05 - NASA Ship
**Date:** 2023-02-02

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events

## Notes
### Background 
Garth looks up to Glurk. Glurk recently completing the trials to become an adult impressed him.

Karx has a vested interest in the [[Chapter Marketplace]]. He's made good deals and contacts there. Last time he had an encounter with someone who needed help traveling outside of town it was at the Marketplace. There was a brawl he helped stop and showed he would defend the Marketplace.

[[Bishop Gabriel]] of the Sacellum of Light is hard on the [[Changed]] as demonic and encourages his flock to harass them to leave Chapter. Karx needed to confront Bishop Gabriel, but knew he needed Glurk's help to tell the Bishop to back off. Glurk agreed and "loomed" sufficiently that the Bishop has avoided Karx.

Garth and Karx used to be rivals. Karx used to work with Eddie (a trader), a rival to Garth. Something changed between them not too long ago. After Garth's crew was killed, Karx agreed to work with him when going to [[Old Lander]] together. Karx is still wary of Garth and Garth still feels guilty.

Masha bailed [[Big Jim Haggart]] out of a jam. She discovered that he couldn't read so she taught him the basics. He has not repaid her yet. Things aren't even yet.

Masha, Karx, and [[Kate Runahan|Goodtime Kate]] were caught up in a flirtatious love triangle where Masha and Karx competed for Kate's affections. Masha and Kate had flirted for several years, but it had never felt quite the right time. When Karx started making a move on Kate, Masha was upset. They began to squabble and snipe at each other in [[Party Towne Pub|Kate's bar]]. After this Kate washed her hands of both of them. Today Karx feels a little angry and bitter about what happened but still holds out hope that Kate will change her mind. Masha feels a little relieved but still protective of Kate when Karx starts getting his hopes us.

Meeka, Karx, and [[Kate Runahan|Goodtime Kate]] had a three-way standoff competing for a choice piece of SALVAGE (define later), Meeka had possession and Karx and Kate bid after it and got into a big fight. Locals tried to take the item from Meeka (anti-[[Skav]] sentiment), roughing her up a little. and she was a bit worse for wear afterward. But Meeka got Kate's friendship out of it when Meeka gave Kate the item.

Glurk's trust was recently betrayed by his boss, Big Jim Haggart. Glurk had sworn to protect a teenager named [[Zion]]. When Glurk went to [[Old Lander]] on an adventure, he asked Big Jim to temporarily protect Zion. Zion got into a fight and got hurt while Big Jim was ignoring him. Glurk hasn't forgiven Big Jim and he is quietly plotting some revenge.

An incident happened at the [[Skav Burrow]] that bonded you all together and it involved [[Kate Runahan|Goodtime Kate]]. The Skavs innocently 'kidnapped' her to teach them about 'good times'. This occurred after Kate washed her hands of Masha and Karx but both were still worried about her so they grabbed the others to try to find her after she went missing. To get her free, they had perform a synchronized dance.

The [[Librarians]] owe Glurk a favor. When Glurk was carrying supplies into the mines for them, part of a tunnel began to collapse which would have cut off several chambers and trapped three people. Glurk held up the ceiling until people could brace it and reinforce it. The Librarians have praised Glurk's actions but haven't repaid him yet.

## Notes 
### Background Notes
- Masha 
	- [[Darlene]] 
	- like family 
	- very tall wants and to explore the unknown 
	- sworn rival
- [[Garth Hernandez|Garth]] 
	- admiration for Glurk has grown after ceremony to be an adult at [[Cloudhaven]] 
- [[Karx]] has vested interest in the Marketplace
	- meeting people that want to leave
	- had to break up a brawl
- [[Masha Richards|Masha]] bailed [[Big Jim Haggart]] out of a jam
	- he can't read and doesn't want anyone to know
	- he owes her a favor in the future 
- [[Glurk]] had his trusted betrayed by [[Big Jim Haggart]] 
	- [[Zion]] had gone to Glurk for protection but he had to go to [[Cloudhaven]] 
	- asked Big Jim to watch and Big Jim didn't do it
- [[Meeka]] 
	- [[Kate Runahan|"Goodtime Kate"]] goes missing, taken to the [[Skav Burrow]] to learn about good times
	- Meeka finally says where she is
	- group bonds  learning a dance
- [[Garth Hernandez|Garth]] and Karx used to be "rivals"
	- Karx worked with another trader
	- rival changed with trip to [[Old Lander]] 
	- Karx feels cautious
	- everything about that part of Garth's life feel guilty
- [[Karx]] needed to confront [[Bishop Gabriel]] 
	- [[Sacellum of Light]] thinks [[Changed]] are Demonic
	- Glurk loomed
- [[Masha Richards|Masha]] and Karx are in a complicated romantic entanglement
	- Masha and [[Kate Runahan|Kate]] had flirted for years
	- Masha was upset when Karx was interested in Kate 
	- Kate washed her hands of both of them
	- Karx feels a little angry, bitter, hopeful
	- [[Masha Richards|Masha]] feels a little relieved
	- why they were worried when Kate was missing 
- [[Glurk]] is owed a favor by the [[Librarians]] 
	- held up a section of the mines that were collapsing
	- hasn't been repaid yet
- [[Meeka]], [[Kate Runahan|Goodtime Kate]], and [[Karx]] in a standoff
	- a piece of salvage that Meeka has that Kate and Karx wants 
	- things get heated and Meeka is a bit worse for wear
	- Meeka and Kate become friends but lost the item

### Current
-  get the wagon unstuck and continue on
- come to an area with a 45 degree angle land/rockslide
- [[Karx]] thinks group is being watched
- [[Cletus]] thinks the group is close and points to an opening in the rocks 
- Glurk is going to pull the wagon instead of [[Dorothy]], but Cletus and the mule will go need the opening 
- Cletus says the opening is more covered up than before
- the skin of the opening appears Old World metal
- Garth notices letters on the side of thing, "ICA"
- [[Meeka]] goes in, Garth lights a goes in
- large area of metal, two stories high 
	- plastic crates, plastic covered papers, water, and debris on floor, 45 angle 
	- water on the floor 
	- stairs lead up to nowhere
	- closed door on the north wall 
- Meeka and Masha go to step in and slip into the debris and water 
- Karx throws a rope to the area they are but slips 
- [[Evers]] looks in with a flashlight
- the water is moving around too much
- something wraps around Karx's left leg and something else around his right leg
	- another wrapped around the middle
- Meeka distracts it by throwing something at it
- Glurk jumps down and hacks it with his halberd
- [[Garth Hernandez|Garth]] and Glurk kill it
- Garth finds a card on a lanard still worn by a skull and spine
	- says NASA which [[Masha Richards|Masha]] knows what that is
- passage to the north leads to another closed door
- [[Glurk]] opens with [[Meeka|Meeka's]] help
- air spells like the airs, not contanmentated by nano particles
- NASA ship with manuals and poster that says "Eradicate the Butcher Menance!"
	- manuals and other NASA salvage
- Glurk opens the hatch that is in the common room
- leads to the engine room
- [[Evers]] points out something that says is important and wants removed
- Garth notices Evers stumbles 
- Meeka notices there is a gas leak
- the area above the engine room doesn't have the gas leak
- clear area north of common room and Glurk forces open a door
- opens to room signs of a struggle
- parts of a NASA robot and parts of the remains of two people
	- one of the people appears partially morphed into a fish
	- Masha finds a few documents and the body of a [[Butchers|Butcher]] creature, 4 foot high ape with parts of metal for a skeleton
- ship shudders
	- Garth goes to check on the people outside
- Brant and Evers look at the things they want 
	- pilot's helmet and ship systems
	- [[Karx]] gets three of the four things that they are interested in
- Brant and Evers have a [[Ghost Shard]] to "protect" the salvage 
- Glurk gets the wagon way before the rocks slide and opening no longer visible
- [[Karx]] and [[Garth Hernandez|Garth]] notices Ferals

##### Navigation
[[Session 04 - Cletus]] | [[Bold Horizons]] | [[Session 06 - The Mighty Ochre]]

