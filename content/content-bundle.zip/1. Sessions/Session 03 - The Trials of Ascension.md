---
sessiondate: 2022-01-06
sessionyear: 2022
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 03 - The Trials of Ascension
**Date:** 2022-01-06

## PCs
- [[Garth Hernandez]] - Human Former Free Trader
- [[Glurk]] - Helot Soldier
- [[Karx]] - Changed Explorer
- [[Masha Richards]] - Human Librarian's Apprentice
- [[Meeka]] - Skav Gatherer

## Events
Several months have passed since the events with [[Father Obadiah Blank]]. There has been no sign of his son, [[Mordechai]], who fled after his father was killed in [[Hazelwood]]. [[The Collection]] was made (taxes to support the [[Chapter Militia|Militia]]) to the usual grumbling.

As they promised the town of [[Chapter]] pulled together and built a [[Companions Cabin|cabin]] for our heroes. It is basically one large room with a fireplace on one end and a variety of odd and end furniture. Cloth dividers hang to create private sleeping space for each person. The outhouse isn’t too far away though the town baths are further. (*+1 Benny to anyone who draws up the cabin*)

### 2140 A.D.
The winter set in and all travel stopped due to the vicious winds and snow. The town held a New Year’s Day party in the [[Council House]] welcoming 2140 A.D. [[Lacey's Playhouse]] put on the Scottish Play and Hamlet. (Anyone participate or attend?) – Ornery people from the Church of the [[Sacellum of Light|New Faith]] shout insults at play-goers, deeming such things as sinful.

The Church of the [[Sacellum of Light|New Faith]] has more attendees during the cold months as [[Bishop Gabriel]] keeps the building toasty for services. The faith is focused on praising God for deliverance and that all should live with humility and repent sins. Hell, it’s something to do.

“Visiting” is a popular way to make the cold dark days pass where people will host friends or even strangers in their home for a meal. Frequently this is used as a way to do matchmaking among the young and the unwed. (*+1 Benny for anyone who participates in these ‘set-ups’*)

Viable Suitors:
- [[Jack Marley]] (male, 20 yrs old, apprentice blacksmith, strong, inventive but quick to anger, sweet face). Father is a farmer tending fields just outside the walls of [[Chapter]], mother is dead.
- [[Paul Veick]] (male, 18 yrs old, handsome and knows it, not really found his calling yet, not a reader, but a real charmer). Parents are [[Librarians]] who don’t understand him. Can hang out where [[Masha Richards|Masha]] is if he wants to.
- [[Damon Frick]] (male, 19 yrs old, intelligent, firmly believes that [[Chapter]] should disband and people live in hiding as the aliens are sure to return any day now ([[Order of Silence]]), says he’ll make a survival homestead as soon as he has enough material.)
- [[Verona Polloc]] (female, 17 yrs old, recently “of age”, very pretty, pursued, fascinated about what makes people different: race, Changes, etc. She has two brothers in the [[Chapter Militia|Militia]], one of whom ([[Bull Polloc|Bull]]) our heroes saved from the avalanche in [[Hazelwood]].
- [[Kree Daniel]] (female, 18 yrs old, wants to be a [[Scouting Guild|Scout]], very curious, anxious about getting lost, long black hair – Arapaho Tribal blood). Being raised by her grandmother who gives a hard eye to any suitor.
- [[Tia Beck|Tia “Turtle” Beck]] (Female, 24 yrs old, very nice but painfully shy, hides from conflict (turtles), very sharp with books). Her father, Simon, is influential among the “[[The Star League|Star League]]” believers and will barter well for good tech.

*This could lead to a Hindrance: Jealous (minor) of other people with the romantic interest or Vow (minor) to make key decisions in consultation with the other.*

### Spring 2140.  

By the time the starts to feel warm again, it is the beginning of March. The vernal equinox is quickly approaching which signals a special time in the [[Helot]] community. They consider this a time of rebirth and renewal.

Ceremony two weeks away, they can make it they move steadily through snowy mountain passes to the eastern slope.

“[[Trials of Ascension]]” – annual ceremonial contest. For young [[Helot|Helots]] it is to pass to adulthood. They receive a ceremonial amulet to signify this milestone. ([[Glurk]] left [[Cloudhaven]] before he could earn one).

[[Librarian Refta|Refta]] and the [[Librarians]] hear a rumor of a cache of Old World books and documents found by a [[Helot]] community. If a group is sent to compete in the Trials and wins, they can claim that cache as their prize and bring it back to [[Chapter]].

All PCs at 3 Advances. All PCs at Reputation 3.

##### Navigation
[[Session 02 - The Right Hand of Nothing]] | [[Bold Horizons]] | TBD

