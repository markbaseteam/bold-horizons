---
aliases: Battle of Moldie Mountain
sessiondate: 2023-02-16
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 06 - The Mighty Ochre
**Date:** 2023-02-16

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events

### Summary 

The Companions were surrounded by [[Ferals]].  But the creatures did not attack.  Instead, in a strange sing song way they called for [[Big Jim Haggart]] to brought to them.  They were controlled by something calling itself the [[Mighty Ochre]] and said Big Jim was a murderer.

They would only allow Garth, Karx, Masha, and Meeka to go, with the others being held as hostages.  Garth agreed, intending that they would get the [[Chapter Militia|Militia]] to come out and rescue the others.  Some of the others seemed more open to the idea of turning the man over though.

Masha learned what she could about Ferals from [[Allie Morgan]] and Karx asked the [[Scouting Guild]].  Garth was the one who convinced Big Jim, but only after other members of the Militia learned that Glurk was one of the hostages.

The Companions returned to the site of the ship and barely avoided another rockslide.  Then they began a long battle against the Ferals.  After fighting through the night, Karx found where Glurk and [[Cletus|Cletus']] had been taken.  Unfortunately, [[Evers]] and [[Brant]] had been killed.

On the way to the Feral camp, Meeka killed two of them with her knife, but then told an elaborate story to minimize her role.  

In the final raid on the camp, Glurk momentarily shrugged off the effects of his wounds.  Though he was eventually overwhelmed by the Ferals, his ferocity caused them to break.

The deaths of the two [[The Star League|Star League]] men allowed Masha to redistribute the salvage from the ship.  She gave some of the manuals they had wanted to the [[Librarians]] instead.

Everyone returned to [[Chapter]], where Big Jim claimed the all the glory for the Militia.

### Fallout

5 [[Chapter Militia|Militia]] men, [[Brant]] and [[Evers]] killed by the [[Ferals|Moldies]]. Cremated in fear of contagion.  
  
### Loot/Pay

Loot from the Icarus spaceship:

- NASA Technical Manuals (5) (Masha --> [[Librarians]])  
- 3 Systems from ship + Pilot's Helmet --> [[The Star League|Star League]]  
- Salvage (50)  
- Poster "Eradicate the [[Butchers|Butcher]] Menace"  
- NASA coffee mugs  
- NASA ID Badge (Garth)  
- NASA shirts  
- NASA Logo pens  
  
Payment for the Job - 200 Salvage for each PC.

### Garth's Thoughts

Garth listened as [[Big Jim Haggart|Big Jim]] claimed all the glory for himself and the [[Chapter Militia|Militia]].  Well mostly for himself.  "Big Jim Braggart" he thought.  He was glad the man gave [[Glurk]] some of the credit at least.  It was the ferocity of the last attack that had convinced the Ferals to retreat, even though Glurk might never use his arm again.  

Still Garth stayed for the whole speech.  He cheered and hurrahed at all the right points.  He'd heard pretty much the same speech last year after the Militia had come out to fight off the [[Ferals]] that had attacked his team.  In fact, he was pretty sure this was the third time in the last year that Big Jim had wiped out all the Ferals.  He wondered how many times you could claim that before people questioned it.

But he didn't really care.  More Ferals were dead and he wasn't.  And his friends weren't either.  And at the end of the day that was all that really mattered.

He was just tired.  He needed a bath and some real sleep.  And to check on [[Molly Kent|Molly]].  It had been a week since he'd seen [[Cletus]] in the [[Chapter Marketplace|Marketplace]].  A week of hard travel to the site of the ship and back to [[Chapter]].  Twice.

He'd talked to Cletus some more on the last trip back.  He was pretty sure he knew who "[[Miss Rachel]]" was.  He debated on telling Cletus she was a widow now, but held back.  He was also pretty sure she was devoted to the [[Sacellum of Light]].  She probably wouldn't live up his perfected fantasy of her.  Cletus was unlikely to live up to her image of god.

He thought about introducing the man to [[Kree Daniel|Kree's]] grandmother.  That sounded like a terrible idea.  He knew he still might do it though.  He laughed out loud and wondered if Cletus would hate him more for leaving him with [[Mighty Ochre|The Ochre]] or the old woman.

The woman wasn't that bad he knew.  Just protective of Kree.  And [[Cletus|Cletus']] stories about the Ferals wouldn't help that.  No it would be a terrible idea. 

He wondered what Kree would say when he told her.

Not even the sight of [[Otis]] in the crowd could ruin his mood.  The [[Blackgold Station|Blackgold]] man had merely noted Glurk's injured arm and raised his eyebrows.  

Garth wondered at that.  He knew it was an observation about Glurk's protection.  But maybe that wasn't all.  Assuming [[Mercy Hospital|Mercy]] couldn't fix it, the [[Helot|Helots]] probably had some way to heal the arm.  And if they didn't then maybe [[Shaun The Broker]] had something in his backroom.  

But if none of those options worked, then someone at [[Blackgold Station]] would for sure have a lead.  Maybe it was time to sort things out with Otis.  

## Notes
- The moldies sway and start talking one word apiece
- the [[Mighty Ochre]] wants the group to bring [[Big Jim Haggart]] who it calls a murdered
- [[Evers]] is in favor of it, [[Brant]] doesn't have an option
- [[Cletus]] doesn't have anything against [[Big Jim Haggart|Big Jim]] but doesn't want to die
- [[Cletus]] wants to go back but Masha with help form Garth convince him he needs to stay
- Garth, Masha, Meeka, and Karx head back to [[Chapter]]  
- Garth says should get the [[Chapter Militia|Militia]] and wipe out the [[Ferals]] 
- Masha to ask the [[Librarians]] if they know of the [[Mighty Ochre]] 
	- talks to [[Librarian Helga]] - older Librarian 
	- told [[Allie Morgan]] at her Laboratory
	- Allie wonders if it is like the book of fairy tales and ogre
	- she wonders if it is reasonable and would make a deal
	- Masha doesn't tell her it wanted Big Jim 
- Karx to check with [[Scouting Guild]] 
	- none heard of the Ochre 
	- heard of [[Ferals]] of talking but not like they did
	- feel like it unusual to have so many, especially after [[Big Jim Haggart|Big Jim]] wiped them out last year
- Garth to talk to [[Big Jim Haggart|Big Jim]] 
	- he is at the [[Council House]] 
	- one of the other militia members speaks up when hears Glurk is there
- next morning and Big Jim with 10 militia 
	- Big Jim on a horse but everyone else on foot
- get about three hours from site and group of 7 [[Ferals]] in the way 
	- they say "Never trust the murderer [[Big Jim Haggart]]"
	- militia stop and the ferals fade into the brush
- no one at the site when the group gets there 
- Karx looks around and see the direction the wagon and the hostages went
	- going up to rougher terrain
- Big Jim orders the militia to set up a defensible camp 
	- Meeka notices that the rockslide might not be done
	- Garth tells Big Jim need a different camp site 
- Karx on the second watch with 3 militia 
	- axe flies out of the darkness and kills a militia member
	- nothing else attacks
	- axe has Big Jim written on it in blood 
- Next morning plan for the Ferals to attack and get in a defensive position
	- Meeka scouts
	- Karx helps with fortifications
	- Garth tries to help with morale
	- Masha points out where they will probably come in
	- lose a militia man but take out some [[Ferals]] 
- next attack 
	- [[Meeka]] sneaks around to try and find the Ochre  
	- Karx fights on the front line
	- Garth shoots moldies 
	- Masha bolters Big Jim 
	- moldies take heavy losses
- all the moldies start running, Meeka yells out "Foldie Moldies"
- Masha helps Garth recover some
- Big Jim tries to help Karx but hurts his back
- Masha helps [[Karx]] 
- head back to the trail Karx had originally seen for the wagon  
- Big Jim tells Meeka to sneak ahead and sees a couple of Ferals swaying
	- she throws a knife into one and it collapses 
	- hides and does the same thing to the other 
- Karx scouts ahead and comes to a clearing with some huts
	- sees [[Cletus]], Dorothy, and [[Glurk]] alive
	- see two other bodies, Evers and Brant are sprouting fungus and mold 
	- bunch of moldies not accounted for 
- Glurk wasn't able to protect Evers and Brant but did protect Cletus 
- Big Jim says load Evers and Brant into the wagon, wrap in [[The Star League]] tarp
- while getting the wagon packed the moldies return to attack
	- Meeka sneaks around 
	- Karx shoots 
	- Garth shoots 
	- Masha boosts [[Big Jim Haggart]]  
	- Glurk throws his spear and terrorizes the moldies but is swarmed
	- his right arm is hurt badly
	- a few militia go down but the moldies flee from Glurk 
- head back to Chapter and the [[Ferals]] don't attack again 
- Big Jim tells the story about how he and the [[Chapter Militia|Militia]] killed dozens of them
	- calls out Glurk as a member of the [[Chapter Militia|Militia]] 
- [[Barnabus Quill]] is there and has Cletus take the stuff from the ship to the [[Armstrong House]] 
- Evers and Brant haven't turned into [[Ferals]] and are quickly cremated
- Masha talks to Cletus and gets his side of the story 
- [[Allie Morgan]] asks Masha what she has 
	- Masha had taken the technical manuals instead of giving to the Star League 
- Positive from both [[Librarians]] and Star League 
- [[Glurk]] gets positive from Big Jim 
- Karx gets positive from [[Scouting Guild]] for letting them know what happened

##### Navigation
[[Session 05 - NASA Ship]] | [[Bold Horizons]] | [[Session 07 - Plague in Daniel]]

