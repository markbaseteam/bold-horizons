---
sessiondate: 2023-10-11
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 19 - Blood Howlers
**Date:** 2023-10-11

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Advances 
- Garth - Steady Hands 
- Glurk - Riding and 
- Masha - Marksman 
- Lefty - Smarts
- Barnabus - Spirit 
### Notes 
- More information from Darius on the leaders of the [[Phoenix State]] 
	- Jack Sampson - President - handsome man, “we’re making life better together“ 
	- Maximillian Kampf - author of "A New Dawn Rises"
	- John Morrow - military leader - he was the one giving the speech in [[Old Lander]] - looking for the Prime base 
- Glurk had heard of Prime Base from when he was in [[Hanging Rocks]].  Someone came from the southeast having fever rants.  Had said he had taken shelter in the Shadow [[Breach Zone]] that was called Prime Base. 
- Decide to head back to [[Chapter]] with info on the Phoenix State after a lot of debate 
- Heading back see larger lightning bugs in a wooded area 
	- Garth hears something up ahead and there are birds making noise in the area 
	- [[Ferals|Blood Howlers]] attack, most are on all fours but one is standing has a hammer
	- [[Barnabus]] kills one swings Mavis at one and it flies out of his hands
	- Kill the rest of them and then [[Half-Assed Tony]] finds their camp.  Looks like there was a place for a second one that walked on two legs. 
	- Glurk takes the hammer and the skull of the champion 
- Garth, Masha, Glurk, and Half-Assed hunt the other [[Ferals|Feral]] 
	- It can call on breech energy and disappears 
	- It causes [[Half-Assed Tony]] to be blind and Garth runs over and shoots it in the head 
- Get to the blocked pass and Lefty uses his teleport power to get the group over the blocked area 

##### Navigation
[[Session 18 - To Old Lander and the Tribe]] | [[Bold Horizons]] | [[Session 20 - Charlotte Weeping Sky]]

