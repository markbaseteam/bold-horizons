---
sessiondate: 2023-03-30
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession, nolog
setting: The After
---
# Session 08 - Plague Hounds
**Date:** 2023-03-30

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Karx]]
- [[Masha Richards]]
- [[Meeka]]

## Events
### Notes 
- midnight and people are looking to close up the church 
- Glurk in the church with Jeremiah
- set up camp behind the church beside where [[Clinton Moss]] is
- Garth and Karx on first watch 
	- fog starts rolling in, very thick 
	- sweet smell drifting on the breeze, like baking in the distance 
	- hear screams and moans from the houses 
	- Masha wakes up, wonders if the smell related to the purple weed 
- Meeka has a nightmare that Karx is hiding the cleat from her 
	- Masha wakes her and Meeka feels sick with fever and chills 
- Meeka climbs up the church to see what is visible from higher
	- is above the fog and can see it is in the fields as well as the town 
	- sees lights in the field 
- Garth hears yipping kind of far off 
	- Meeka thinks the sounds is around the lights 
	- hear the sound of sheep being killed
- Meeka climbs down and the group heads for the fields 
- the screams and moans seem to come in waves 
- Meeka can see the lights are green glowing eyes 
- two wolf like creatures, two heads, around 6 hound pounds 
![](https://i.imgur.com/DlgXfiU.png)
- Karx sees a third and blasts it with his shotgun 
- another one appears in front of Meeka, with its mouths open and fire forming 
	- Meeka throws a dagger down its throat 
	- it shakes it off and unleashes fireballs
	- Garth and Masha jump out of the way
- another rums up to Masha to bite her, shaken
- groups starts to retreat back to a house
- Masha hurt by a fireball 
- one of the creatures makes it into the house 
- Garth kills two 
- Karx kills one and blocks the door with a table 
- Meeka runs for help at the church 
- Masha kills one with her bow 
- Garth throws a grenade out the two and takes out two 
- Meeka rings the bell but no one wakes up 
- Check [[Clinton Moss]] wagon and the horses are gone and he isn't there 
- Karx finds the horse on the other side of the hill, to the east
- See Clinton in the village handing out his cure 

##### Navigation
[[Session 07 - Plague in Daniel]] | [[Bold Horizons]] | [[Session 09 - Meeka Gets Worse]]