---
sessiondate: 2023-09-28
sessionyear: 2023
campaign: "Bold Horizons"
tags: session, AfterSession
setting: The After
---
# Session 18 - To Old Lander and the Tribe
**Date:** 2023-09-28

## PCs
- [[Garth Hernandez]]
- [[Glurk]]
- [[Masha Richards]]
- [[Lefty]]
- [[Barnabus]] 

## Events
### Notes 
- Gear from [[Phoenix State]] soldiers 
	- Four bolt-action hunting rifles with scopes (green-oiled) 
	- "Plenty" of ammunition for the rifles 
	- Four combat knives 
	- Two tents 
	- Four sleeping bags 
	- Four kevlar vests 
	- 3 Old World hand grenades (green-oiled)
	- Four Phoenix State uniforms (with blood) 
	- Hats, Boots 
	- 4 Masks/Breathers 
	- 4 Cloaks 
	- canteens of water 
	- rations 
	- 4 Canteens of "Green Tea"
- Gluck can’t wear the Phoenix State gear because of size and the Phoenix State is again aliens and [[Changed]] 
- [[Half-Assed Tony]] doesn’t find anything that would lead us to go anywhere other than Lander 
- Lefty on watch and hears blood curdling wolf howls off in the distance 
- Barnabas finds the tracks but isn’t familiar with them. The tracks are not going the direction the group is going.
- Get within sight of Old Lander and do not encounter any Phoenix State 
- Look into the town and see very few people
	- A truck and a couple of ATVs
	- About 10 people loading the truck up to leave 
- Also see a wisp of smoke in another part of town that is outside the camp 
- Two people on each ATV and the rest in the truck 
	- They head southeast 
- Head into the town to check out the camp site in the uniforms 
	- It is deserted except for garbage 
	- Masha takes some unburnt papers from burn barrels 
	- [[Phoenix State]] uses same alphabet 
	- A couple of diagrams showing the area 
	- Line in a loop from [[Old Lander]] south around the mountains up through [[Blackgold Station|Blackgold]] (misses [[Highway Market]]) through the pass to Chapter and to Old Lander 
- Check out the rest of the town to see what was smoking 
	- See a family of monkeys but with iron claws 
	- The smoldering area was a building 
	- Human sized cages and burnt bodies, two show signs of having been changed and one has mechanical body parts. It is the left arm which Glurk is missing 
- Look for the Helot family that lived here before, their huts had been destroyed and they have been dead for weeks 
	- Find a torn journal.  Mostly prayers to [[Kraim]] and everyday life, but not about [[Phoenix State]] arriving and considering heading to the mountains but evidently didn’t do so.
	- Take their amulets and the journal to give to [[Hanging Rocks]] when get a chance 
	- Take the bodies down and do rites for [[Kraim]] 
- Take shelter in a barn 
	- Masha’s watch hears the wolves again 
	- Wakes Lefty and pay attention 
	- The sound just stops suddenly, the previous night it had faded out 
	- Normal nature sounds resume after a few minutes 
- See tracks of larger vehicles and some horses also going southeast on the general route the truck went 
- Head north to find the leaders of [[The Tribe]] 
- Hear a rumbling ahead of the group. Head for higher ground amongst trees.
	- a herd of buffalo that appear to be covered in stone and moss 
	- Glurk wants to try and ride one (Adventure Card - Ace to succeed)
	- One bumps into Glurk, eyes somewhat covered with stone so doesn’t have great vision 
	- Glurk climbs onto and it starts bucking and running.  He is thrown off of it and lands hard on rocky ground.
	- Glurk’s halberd snaps the handle (Crit Fail)
	- Glurk tries again and able to stay on it as it runs through trees 
	- Lefty calls on the breech energy to protect him from the trees and Glurk isn’t thrown 
	- Glurk fashions some reins and hammers spikes into it 
- Go further north than expected and eventually encounter a Tribal woman 
	- Lefty says looking for information on the [[Phoenix State]] 
	- She asks what there is to trade and mention Phoenix State gear 
	- Feel like the groups as expected 
- 4 women and 2 men, men seem to be guards 
	- Garth had told Masha would be best if she did the talking and tried to give her info on [[The Tribe]] 
	- Offer the tents in trade - Tribe has seen the soldiers and so far have avoided them.  Don’t think the Phoenix State knows of “[[The Tribe]]”.  They didn’t spend a lot of time in the area, scouted and went back south to Old Lander. Tribe scouted south and the Phoenix State went between the Rustyard and ruins. 
	- Add two of the Kevlar vests to the trade - Was a wanderer, [[Darius]], from the east that wasn’t a soldier that came to the Tribe seeking refuge.  How they first heard of the soldiers, call them Bird Soldiers.  The soldiers have control of several settlements in the east and keep expanding. 
	- Add two of the bolt-action rifles to the trade - They are willing to send a runner in search of [[Darius]].
	- Ask the tribe about the wolf howls, called [[Ferals|Blood Howlers]], a form of Ferals.  Humanoid and uses tools.
- Darius found the next day (Adventure Card - Here Comes the Cavalry)
	- Gawks at the stone buffalo and Glurk, had never seen either before 
	- His face darkens when Garth tells him the Phoenix State had attacked [[Chapter]] 
	- Asks the group to tell about themselves 
	- Darius was a leather worker/tanner/cobbler in Athens Creek, out in the middle of nowhere in what was known as Kansas 
	- Born when the [[Butchers|Butcher]] and [[Ghosts]] were still fighting.  Was focused on his family until the [[Phoenix State]] arrives. 
	- Council of Elders went to meet with the Phoenix State and never returned, rumors that they were executed.
	- Phoenix State conscripted the men.  Darius fought back to defend the women of the town. Jailed and sent to the mines.
	- Jonah led a revolt which was put down, but he escaped and went west until ran into [[The Tribe]] 
	- Doesn’t believe any of the Phoenix State propaganda 
	- Show him the document from the burn barrel - Unit on the mission was meeting allies in Chapter and decide what to steal 

##### Navigation
[[Session 17 - Gonna Get Married]] | [[Bold Horizons]] | [[Session 19 - Blood Howlers]]

