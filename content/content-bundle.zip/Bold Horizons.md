---
home: true
---
# The After
A Savage Worlds campaign by Big Dog.

## PCs
- [[Garth Hernandez]] - Human Former Free Trader
- [[Glurk]] - Helot Soldier
- [[Karx]] - Changed Explorer
- [[Masha Richards]] - Human Librarian's Apprentice
- [[Meeka]] - Skav Gatherer

![](https://i.imgur.com/ClgJML5.png)
