---
aliases: Helots
tags: Race
---
# Helot
“You couldn’t ask for a better watchman than a Helot. Most folk with trouble on their minds will turn the other way just seeing the size of ‘em. And a Helot on guard duty won’t shirk. Doesn’t matter if it’s hot as blazes, pouring rain, or snowing fit to bury you, they’ll keep watch proper, like it doesn’t even bother them. See, they believe their god is watching from the stars, waiting to lead the most steadfast of ‘em back to their homeworld, wherever that is.

“Oh, you think that’s a bunch of hooey? Don’t say it where they can hear you, then. Helots take everything seriously - especially when it comes to religion. You’re likely to end up face-down in the mud.”

-[[Big Jim Haggart]]

- Hulking, resilient aliens with blue skin marked by pebbly white patterns. They are strong and have high endurance.  
- Slave race to the [[Butchers]] who escaped and survived.  
- More than 200 Helots call the [[Wind River Valley|Wind River]] home, a few in [[Chapter]] but most elsewhere like the Helot village of [[Cloudhaven]].  
- Helots worship [[Kraim]] "He Who Covers the Sky" loudly and often.  
- Generally calm and slow to experience extremes of emotion. They value community-building.