---
tags: Contest
---
## Trials of Ascension
An annual ceremonial contest in [[Cloudhaven]] for young [[Helot|Helots]] it is to pass to adulthood. They receive a ceremonial amulet to signify this milestone. ([[Glurk]] left Cloudhaven before he could earn one).