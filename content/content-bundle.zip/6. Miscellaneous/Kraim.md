---
tags: Deity
---
# Kraim
“He Who Covers the Sky”.  A [[Helot]] a deity that values hard work, unswerving dedication, patience, and endurance.