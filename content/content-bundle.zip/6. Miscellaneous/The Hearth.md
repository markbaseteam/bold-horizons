---
aliases: the Hearth, Hearth Ghost Shard
tags: Shards
---
# The Hearth
A shard that makes it warmer for a few miles around [[Chapter]].