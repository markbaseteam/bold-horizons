---
tags: Race
---
# Changed
“All of us are changed in some way or another, honey. What the [[Butchers]] and [[Ghosts]] did to this world, it’s in the air we breathe and the water we drink, whether we like it or not. Just because you and I seem pretty close to the pictures you’ve seen in your library books, that doesn’t mean you aren’t a little different on the inside. Old Bob over there, he’s just got his changes on the outside, too. I know what your daddy says, but you don’t need to be scared of Old Bob. He isn’t an animal. Don’t mind the fur and the teeth. I taught him how to read, same as I’m teaching you and your sister. He’s a nice fellow. He likes to play checkers, you know.”

-[[Allie Morgan]]

- During the Harvest, [[Butchers]] dropped GenBombs releasing clouds of mutagenic nanites triggering immediate and often catastrophic changes in fauna, flora, and people.  
- There are a few Changed in [[Chapter]] and most everywhere.  
- Changes are often very obvious and biomechanical.  
- They are often feared and shunned by others in [[Wind River Valley|Wind River]].  
- Changed have some physical mark that is hard to hide, one Major Anomaly and two Minor Anomalies