---
aliases: The Harvest, the Harvest, Harvest, GenBomb, Butcher machines, Butcher
tags: Aliens
---
# Butchers
The first aliens who attacked the Earth almost ignoring humanities attempts to harm them. They never communicated. The slaughtered millions but also harvested millions for gruesome experimentation in massive grounded factory ships. Released "GenBomb" clouds of mutagenic nanites to decay technology and attack people they might not be able to find with their weapons. The armies of the Butchers were filled with the twisted and tortured races from planets of previous conquest and very rarely a Butcher. Rumors survive to this day that a Butcher was over fifty feet tall and strode across the battlefield like a massive armored beast. The era of Butcher dominion is known as The Harvest.