---
aliases: The Boon, the Boon, Breachrunner, Fleshcrafter, Mindbender, the Gifted
tags: Rules
---
# Gifted
- Energy left by the [[Ghosts|Ghost aliens]] and the breaches in reality they created can touch people and cause physical and psychic changes.  
- Those affected call themselves Gifted and the changes as the Boon.  
- Some fear the Gifted while others appreciate the benefits the Gifted bring.  
- They fall into three types:  
	- Breachrunner: reaches directly into [[Breach Zone|the Breach]], pulling out raw extradimensional energy. They are flashy, explosive, noisy, and never subtle.  
	- Fleshcrafter: Summon forth [[Breach Zone|Breach energy]] to make temporary physical mutations in themselves and others with sudden, shocking changes.  
	- Mindbender: Sees through the cracks in the world caused by [[Breach Zone|the Breach]], using those openings to extend their senses and influence the minds of others.