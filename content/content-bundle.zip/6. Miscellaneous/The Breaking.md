---
aliases: the Breaking
tags: Event
---
## The Breaking

In April 2090, a titanic impact or explosion cracked the Moon.  The Breaking resulted in further destruction for the remnants of mankind, as debris from the explosion crashed to Earth in a series of horrific impacts, leaving immense craters. However, this disaster also ushered in a new phase of the War between [[Butchers]] and [[Ghosts]]. Both races vanished from Earth’s surface, shifting their conflict into the far reaches of our solar system - and perhaps even farther!