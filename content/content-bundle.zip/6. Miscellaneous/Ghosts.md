---
aliases: Ghost aliens, Ghost
tags: Aliens
---
# Ghosts
The second alien race who appeared to arrive simply to bring war to the [[Butchers]]. They also never acknowledged the attempts of humans to communicate. Their arrival tore holes in reality many of which survive to this day as [[Breach Zone|Breach Zones]]. The Butcher-Ghost war brought decades of even more destructive war across the face of the Earth and its skies. Their broken ships plummeted to Earth (called "The Fall"). They even cracked the Moon in half.