---
aliases: Skavs
tags: Race
---
# Skav
“Somewhere down in those warrens they’ve got a Council, they’ve got elders just like [[Chapter]] does. I know, they won’t admit it. Any Skav would die first. But someone down underground is calling the shots, sayin’ how the Skav will change next.

“Yeah, change. When they first came down from the sky, they looked more like bugs - big creepy eyes, a little bit of a carapace, and spindly legs that bent backward. Them dreadlocks used to be antennae. They’ve been mutating quick. The form changes a little with every generation, and theirs come faster than ours. I know it had to be done a-purpose so that we humans would like the Skav better, would be less inclined to kill them the rest of the way off. That’s why they tinker for cheap, and trade fair, and why they’ve taught their children to mostly eat food we’re not interested in.

“I’m pretty sure they’re only pretending to have two genders to make us more comfortable with ‘em.”

-[[Zachariah Cole]]

- A nimble, fast-breeding, and quick-evolving alien race who stowed away on the [[Butchers]]' Goliath mother ships.  
- Skav adapt quickly, taking on helpful traits even in a single generation or two. Today's Skav are much better suited to the cold climate of [[Wind River Valley|Wind River]].  
- They are friendly and accommodating, ingratiating smoothly in human settlements with a talent for tinkering and repairing technology.  
- Definitely very curious and tend to try anything.  
- Prefer communal living, lack a sense of privacy, and share things.  
- Speak of "Mother" as in "Mother save us!" and "I swear by Mother!"